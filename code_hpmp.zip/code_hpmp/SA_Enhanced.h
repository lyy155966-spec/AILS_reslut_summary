#ifndef SA_ENHANCED_H_
#define SA_ENHANCED_H_

#include "Individual.h"
#include "read_data.h"
#include <vector>
#include <algorithm>
#include <set>
#include <limits>

// 前置声明
class MyLS;

class SA_Enhanced {
public:
    SA_Enhanced(read_data* data);
    virtual ~SA_Enhanced();
    
    void run(Individual* currentSol,
             MyLS* ls,
             double& bestDistance,
             int& bestFoundAtIteration,
             int& finalIteration,
             double stopTemperature = 0.0012,
             int episodeLength = 50,
             int restartInterval = 100000000);
    
    // 主要接口
    void perturb(Individual* solution);                    // 智能扰动
    virtual bool acceptSolution(Individual* current, Individual* localBest, Individual* globalBest); // 三解SA接受准则
    void updateTemperature();                              // 更新温度
    void updateOperatorWeights();                          // 更新操作符权重
    void resetWeights();                                   // 重置权重（周期性）
    
    // 定期重启机制（模仿SA.cpp的segment % re_start == 0）
    void periodicRestart(double currentBestDis, int restartInterval, int episodeLength);
    
    // 温度相关
    double getTemperature() const { return temperature; }
    void setInitialTemperature(double temp) { initialTemperature = temp; temperature = temp; }
    void initializeTemperature(Individual* solution);  // 移到公有部分
    
    // 统计信息
    int getLastUsedOperator() const { return lastUsedOperator; }
    void recordImprovement(int operatorId, double improvement);
    
    // 三解管理
    Individual* globalBest;     // 全局最优解
    Individual* localBest;      // 局部最优解
    void setGlobalBest(Individual* global) { globalBest = global; }
    void setLocalBest(Individual* local) { localBest = local; }

private:
    read_data* data;
    int num_v;
    int num_groups;
    
    // Shaw removal需要的辅助变量
    std::vector<int> cityRank;  // 存储候选节点
    double determinePara;        // Shaw removal偏向性参数，通常为6
    
    // 优化：预处理的约束列表
    std::vector<std::pair<int, int>> precedenceList;  // 存储所有先后约束对 (i, j)，表示i必须在j之后
    
    // mustAfter和mustBefore已移至read_data中，通过data->mustAfter和data->mustBefore访问
    
    // SA参数
    double temperature;
    double initialTemperature;
    double coolingRate;
    double lastTemperature;              // 最终温度（模仿SA.cpp的last_temperature）
    int iterationCount;
    int segmentCount;                    // 权重更新段计数
    
    // 破坏算子管理
    static const int NUM_DESTROY_OPERATORS = 4;
    double destroyWeights[NUM_DESTROY_OPERATORS];
    double destroyScores[NUM_DESTROY_OPERATORS];
    int destroyUsage[NUM_DESTROY_OPERATORS];
    double destroyCumulativeProb[NUM_DESTROY_OPERATORS];
    int lastUsedDestroy;
    
    // 修复算子管理
    static const int NUM_REPAIR_OPERATORS = 5;
    double repairWeights[NUM_REPAIR_OPERATORS];
    double repairScores[NUM_REPAIR_OPERATORS];
    int repairUsage[NUM_REPAIR_OPERATORS];
    double repairCumulativeProb[NUM_REPAIR_OPERATORS];
    int lastUsedRepair;
    
    // 最后使用的操作符（组合）
    int lastUsedOperator;
    
    // 自适应学习参数
    double learningRate;                 // 权重学习率 (gamma)
    int updateInterval;                  // 权重更新间隔
    
    // 分层奖励系统
    static const int REWARD_GLOBAL_BEST = 10;
    static const int REWARD_LOCAL_IMPROVE = 5;
    static const int REWARD_ACCEPT = 3;
    
    // 温度控制参数
    double acceptanceProbability;        // 目标接受概率
    double temperatureParameter;         // 温度计算参数
    
    // 破坏算子（只移除节点）
    std::vector<int> randomDestroy(Individual* solution, double ratio = 0.4);
    std::vector<int> shawDestroy(Individual* solution, double ratio = 0.4);
    std::vector<int> worstDestroy(Individual* solution, double ratio = 0.4);
    std::vector<int> precedenceDestroy(Individual* solution, double ratio = 0.6);
    
    // 修复算子（只插入节点）
    void greedyRepair(Individual* solution, std::vector<int>& removedNodes);
    void greedyBlinkRepair(Individual* solution, std::vector<int>& removedNodes);
    void regretRepair(Individual* solution, std::vector<int>& removedNodes);
    void randomRepair(Individual* solution, std::vector<int>& removedNodes);
    void clusterSwapRepair(Individual* solution, std::vector<int>& removedNodes);
    
    // 算子选择和执行
    int selectDestroyOperator();
    int selectRepairOperator();
    std::vector<int> executeDestroyOperator(int operatorId, Individual* solution);
    void executeRepairOperator(int operatorId, Individual* solution, std::vector<int>& removedNodes);
    
    // 直接链表操作（参考SA.cpp风格）
    void removeNodeFromList(Individual* solution, int nodeIndex);
    void insertNodeAfter(Individual* solution, int nodeToInsert, Node* afterThis);
    
    // 约束检查（基于链表遍历）
    bool checkNodeConstraints(Individual* solution, int node);  // 增量式约束检查
    
    // 成本计算
    double calculateInsertionCost(Node* afterThis, int nodeToInsert);
    
    // 初始化函数
    void initializeWeights();
    void updateDestroyCumulativeProb();  // 更新破坏算子累积概率
    void updateRepairCumulativeProb();   // 更新修复算子累积概率
    
    // 三解管理辅助函数
    bool isGlobalImprovement(Individual* current);
    bool isLocalImprovement(Individual* current);
    void recordOperatorSuccess(int destroyId, int repairId, int rewardType);
};

// 奖励类型枚举
enum RewardType {
    GLOBAL_BEST = 0,
    LOCAL_IMPROVE = 1,
    ACCEPT_ONLY = 2
};

#endif /* SA_ENHANCED_H_ */
