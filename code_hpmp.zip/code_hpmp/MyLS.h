#ifndef MYLS_H_
#define MYLS_H_

#include "Individual.h"
#include "read_data.h"

class MyLS {
public:
    // 构造函数：初始化数据指针
    MyLS(read_data* data);
    // 析构函数
    virtual ~MyLS();
    
    // 主函数：执行局部搜索
    void local_search_run(Individual* s);
    // 主循环：类似LS::srun()
    void srun();
    
private:
    // 局部搜索操作符
    bool move_twoOpt();         // 2-opt操作：反转路径中的一段
    bool move_relocate();       // Relocate操作：重定位单个节点
    bool move_swap();           // Swap操作：交换两个节点的位置
    bool move_nodeReplacement();// NodeReplacement操作：用nodeV同簇的其他节点替换nodeV
    
    // 辅助函数
    void insertNode(Node* U, Node* V);  // 将节点U插入到节点V之后
    void swapNode(Node* U, Node* V);    // 交换两个节点的位置
    bool checkRelocate(Node* U, Node* insertAfter);  // 检查relocate是否满足优先级约束
    bool checkSwap(Node* U, Node* V);   // 检查swap是否满足优先级约束
    bool checkNodeReplacement(int newNode, Node* oldNode);  // 检查节点替换是否满足优先级约束
    
    // 更新路径信息（距离、位置等）
    void updateRouteData(int& r);
    
    // 检查优先级约束：验证反转区间内的节点是否满足约束
    bool checkPrecedenceConstraints(Node* segmentStart, Node* segmentEnd);
    
    // 设置局部变量（类似LS）
    bool setLocalVariableRouteU();
    bool setLocalVariableRouteV();
    
    // 初始化解（类似LS::load_solution）
    void load_solution();
    
    /********************************************/
    // 数据成员
    read_data* data;      // GTSP问题数据
    Individual* s;        // 当前解
    int num_v;            // 节点数量
    int num_p;            // 路径数量（p=1）
    
    // 节点顺序和邻域相关
    std::vector<int> orderNodes;  // 节点访问顺序
    Node* nodeU;          // 当前选择的第一个节点
    Node* nodeX;          // nodeU的下一个节点
    Node* nodeV;          // 当前选择的第二个节点
    Node* nodeY;          // nodeV的下一个节点
    
    // 节点索引（用于快速访问距离矩阵）
    int nodeUPrevIndex, nodeUIndex, nodeXIndex, nodeXNextIndex;
    int nodeVPrevIndex, nodeVIndex, nodeYIndex, nodeYNextIndex;
    
    // 搜索控制变量
    bool searchCompleted;  // 单次循环是否完成
    bool searchComplete;   // 整体搜索是否完成
    int loopID;            // 当前循环ID
    int nbMoves;           // 移动次数计数器
    
    // mustAfter和mustBefore已移至read_data中，通过data->mustAfter和data->mustBefore访问
    
    // 辅助函数：增量式约束检查
    bool checkNodeConstraintsIncremental(int node, const std::vector<int>& currentPath);
};

#endif /* MYLS_H_ */
