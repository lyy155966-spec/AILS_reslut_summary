/*
 * readdata.h
 *
 *  Created on: 17 Apr 2020
 *      Author: Peng
 */

#ifndef READ_DATA_H_
#define READ_DATA_H_
#include <time.h>
#include "basic.h"
class read_data {
public:
	//general variables
	int iteration=0;//迭代次数计数器
	int nbIterNonImpro;//无改进次数计数器
	int num_v;//节点数量
	int num_p;//p中心数量=1
	clock_t startTime;//开始时间
	int timeLimit;//时间限制
	int iterLimit;//迭代次数限制
	double meetBestTime=Max;//达到最优解的时间
	double timeToTarget=Max;//达到目标解的时间
	int isOptimal;//是否达到最优解
	bool meetOptimal=true;//是否达到最优解
	//parameters
	double mutationPer = 0.1;//变异概率
	int maxIterNonProd=30000;
	int alpha=20;  // 修改为10，测试更小的邻域
	int popMin=50;
	int genSize=25;
	int popMax=popMin+genSize;

	int nbClost=5;//parameters for measuring distance
	int nbElite=4;//parameters for measuring distance
	std::vector < std::vector < int > > edge_node;
	std::vector < std::vector < int > > nearCity;
	int **correctedEdge;
	double ** D;// distance between all cities
	double *x;
	double *y;
	double bestDis;



	// GTSP specific variables
	bool isGTSP = false;                          // 标识是否为GTSP问题
	int num_groups;                               // 簇的数量
	int startGroup;                               // 起始簇编号
	std::vector<int> nodeGroup;                   // nodeGroup[i]表示节点i属于哪个簇
	std::vector<std::vector<int>> groupNodes;     // groupNodes[g]表示簇g包含的所有节点
	int **precedenceConstraints;                  // precedenceConstraints[i][j]=-1表示节点i必须在节点j之后
	int **sameCluster;                            // sameCluster[i][j]=1表示节点i和j在同一簇
	
	// 预处理的约束数据（用于增量式检查）
	std::vector<std::vector<int>> mustAfter;      // mustAfter[i] = 节点i必须在哪些节点之后
	std::vector<std::vector<int>> mustBefore;     // mustBefore[i] = 哪些节点必须在节点i之后

	


	read_data();
	virtual ~read_data();
	void define();
	void define_gtsp();                          // 为GTSP分配额外内存
	void read_fun(std::string pathInstance,std::string pathSolution, int nump, double bestDis, int isOptimal, int timeLimit,int iterLimit,int seed);
	void read_gtsp(std::string pathInstance,std::string pathSolution, int nump, double bestDis, int isOptimal, int timeLimit,int iterLimit,int seed);
	void preprocessPrecedenceConstraints();      // 预处理约束：构建mustAfter和mustBefore
	bool stopCondition(double dis);
	std::string pathSolution;     // used to file name of output best solution
	std::string pathInstance;
private:
	std::string typeGraph;
	std::string matrix_row;
	double dtrunc (double x);
};

#endif /* READ_DATA_H_ */
