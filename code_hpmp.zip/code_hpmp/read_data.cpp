/*
 * readdata.cpp
 *
 *  Created on: 17 Apr 2020
 *      Author: Peng
 */

#include "read_data.h"
#include "basic.h"
#include "Individual.h"
#include <sstream>
read_data::read_data() {

}
read_data::~read_data() {
	for (int i=0;i<num_v;i++)
		delete [] D[i];
	delete [] D;
	delete [] x;
	delete [] y;
	for (int i=0;i<num_v;i++)
		delete [] correctedEdge[i];
	delete [] correctedEdge;
	
	// 释放GTSP相关内存
	if (isGTSP) {
		for (int i=0;i<num_v;i++) {
			delete [] precedenceConstraints[i];
			delete [] sameCluster[i];
		}
		delete [] precedenceConstraints;
		delete [] sameCluster;
	}
}
void read_data::define(){
	D=new double *[num_v];
	for (int i=0;i<num_v;i++)
		D[i]=new double [num_v];
	x=new double [num_v];
	y=new double [num_v];
	correctedEdge=new int *[num_v];
	for (int i=0;i<num_v;i++)
		correctedEdge[i]=new int [num_v];
	for (int i=0;i<num_v;i++)
		for (int j=0;j<num_v;j++)
			correctedEdge[i][j]=0;
	edge_node=std::vector<std::vector<int>>(num_v);
	nearCity = std::vector< std::vector < int > >(num_v);
}
void read_data::read_fun(std::string pathInstance, std::string pathSolution, int nump, double bestDis, int isOptimal, int timeLimit,int iterLimit,int seed){
	/****imput information*******/
	this->timeLimit=timeLimit;
	this->iterLimit=iterLimit;
	this->num_p=nump;
	this->bestDis = bestDis;
	this->isOptimal=isOptimal;
	/*********************************************************/
	this->pathSolution=pathSolution;
	this->pathInstance=pathInstance;
	/*********************************************************/
	// read the input file
	std::string content, content2, content3;
	int temVar;
//	std::cout<<pathInstance<<std::endl;
	std::ifstream inputFile(pathInstance);
	if (inputFile.is_open()){
		for (inputFile >> content ; ((content != "NODE_COORD_SECTION") && (content !="EDGE_WEIGHT_SECTION")) ; inputFile >> content){
			if (content == "DIMENSION"){inputFile >> content2 >> num_v;} // Need to substract the depot from the number of nodes
			else if (content == "DIMENSION:"){inputFile >> num_v;}
			else if (content == "EDGE_WEIGHT_TYPE"){inputFile >> content2 >> typeGraph;}
			else if (content == "EDGE_WEIGHT_TYPE:"){inputFile >> typeGraph;}
			else if (content == "EDGE_WEIGHT_FORMAT:"){inputFile >> matrix_row;}
			else if (content == "EDGE_WEIGHT_FORMAT"){inputFile >> content2 >> matrix_row;}
//			else if (content == "OPTIMALSOLUTION:"){inputFile >> OptimalLB;}
//			else if (content == "isOPTIMAL:"){inputFile >> wheatherOptimal;}
		}
		define();
		if (typeGraph == "EXPLICIT"){
			if (matrix_row == "UPPER_ROW"){
				for (int i=0;i<num_v;i++){
					D[i][i]=0;
					for (int j=i+1;j<num_v;j++){
						inputFile>>D[i][j];
						D[j][i]=D[i][j];
					}
				}
			}
			else if (matrix_row == "LOWER_DIAG_ROW"){
				for (int i=0;i<num_v;i++){
					for (int j=0;j<= i;j++){
						inputFile>>D[i][j];
						D[j][i]=D[i][j];
					}
				}
			}
			else if (matrix_row == "FULL_MATRIX"){
				for (int i=0;i<num_v;i++)
					for (int j=0;j<num_v;j++)
						inputFile>>D[i][j];
			}
		}
		else{
			for (int i=0;i<num_v;i++){
				inputFile>>temVar;
				inputFile>>x[i];
				inputFile>>y[i];
			}
		}
	}
	else{
		std::cout<<"The input file was wrong"<<std::endl;
		exit(0);
	}
	inputFile.close();
	if (typeGraph == "EUC_2D"){
		for (int i=0;i<num_v;i++){
			for (int j=0;j<num_v;j++){
				D[i][j]=(sqrt((x[i]-x[j])*(x[i]-x[j])+(y[i]-y[j])*(y[i]-y[j])));
			//	D[i][j]=int((sqrt((x[i]-x[j])*(x[i]-x[j])+(y[i]-y[j])*(y[i]-y[j])))+0.5);
			}
		}
	}
	if (typeGraph == "GEO"){
	    double deg, min;
	    double lati, latj, longi, longj;
	    double q1, q2, q3;
	    int dd;
	    double x1,x2,yy1,yy2;
		for (int i=0;i<num_v;i++){
			for (int j=0;j<num_v;j++){
				x1=x[i];x2=x[j];
				yy1=y[i];yy2=y[j];
				deg=dtrunc(x1);
				min=x1-deg;
				lati=PI * (deg + 5.0 * min / 3.0) / 180.0;
				deg=dtrunc(x2);
				min=x2-deg;
				latj=PI * (deg + 5.0 * min / 3.0) / 180.0;
				//
				deg=dtrunc(yy1);
				min=yy1-deg;
				longi=PI * (deg + 5.0 * min / 3.0) / 180.0;
				deg=dtrunc(yy2);
				min=yy2-deg;
				longj=PI * (deg + 5.0 * min / 3.0) / 180.0;
				//
				q1=cos (longi-longj);
				q2=cos (lati - latj);
				q3=cos (lati + latj);
				dd=(int)(6378.388 * acos (0.5 * ((1.0 + q1) * q2 - (1.0 - q1) * q3)) + 1.0);
				D[i][j]=dd;
			}
		}
	}
	if (typeGraph == "ATT"){
		double xd,yd,rij,tij,dij;
		for (int i=0;i<num_v;i++){
			for (int j=0;j<num_v;j++){
				xd=x[i]-x[j];
				yd=y[i]-y[j];
				rij=sqrt((xd * xd + yd * yd) / 10.0);
				tij=dtrunc(rij);
				if (tij < rij)
					dij = (int)tij+1;
				else
					dij=(int)tij;
				D[i][j]=dij;
			}
		}
	}
	if (typeGraph == "CEIL_2D"){
		double t1,t2;
		for (int i=0;i<num_v;i++){
			for (int j=0;j<num_v;j++){
				t1=x[i]-x[j];
				t2=y[i]-y[j];
				D[i][j]=(int) (ceil(sqrt(t1*t1 + t2*t2)));
			}
		}
	}
	/* construct sparse graph****************/
	std::vector < std::set < int > > setCorrelatedVertices = std::vector < std::set <int> >(num_v);
	std::vector < std::pair <double, int> > orderProximity;
	for (int i = 0; i <num_v; i++){
		orderProximity.clear();
		for (int j = 0; j <num_v; j++)
			if (i != j) orderProximity.push_back(std::pair <double, int>(D[i][j], j));
		sort(orderProximity.begin(), orderProximity.end());
		for (int j = 0; j < std::min<int>(alpha, num_v - 2); j++){
			setCorrelatedVertices[i].insert(orderProximity[j].second);
			setCorrelatedVertices[orderProximity[j].second].insert(i);
		}
		for (int j=0;j < (int)orderProximity.size();j++)
			nearCity[i].push_back(orderProximity[j].second);
	}
	// Filling the vector of correlated vertices
	for (int i = 0; i <num_v; i++)
		for (int x : setCorrelatedVertices[i])
			edge_node[i].push_back(x);
	for (int i=0;i<num_v;i++)
		for (int j=0;j<(int)edge_node[i].size();j++)
			correctedEdge[i][edge_node[i][j]]=1;
}
double read_data::dtrunc (double x){
    int k;
    k = (int) x;
    x = (double) k;
    return x;
}
bool read_data::stopCondition(double dis){//stopping condition function
	if ((double)clock()/(double)CLOCKS_PER_SEC > timeLimit)
		return true;
	if (iteration > iterLimit)
		return true;
	if ( meetOptimal && bestDis > dis + Min){
		timeToTarget = (double)clock()/(double)CLOCKS_PER_SEC;
		meetOptimal = false;
	}
	if (std::abs(bestDis - dis) < 0.01){
		if (isOptimal)return true;
	}

	return false;
}

// 预处理先后约束：构建mustAfter和mustBefore
void read_data::preprocessPrecedenceConstraints() {
	if (!isGTSP) return;  // 非GTSP问题不需要预处理
	
	mustAfter.clear();
	mustBefore.clear();
	mustAfter.resize(num_v);
	mustBefore.resize(num_v);
	
	for (int i = 0; i < num_v; i++) {
		for (int j = 0; j < num_v; j++) {
			if (precedenceConstraints[i][j] == -1) {
				// precedenceConstraints[i][j]=-1 表示节点i必须在节点j之后
				mustAfter[i].push_back(j);   // 节点i必须在节点j之后
				mustBefore[j].push_back(i);  // 节点j之前必须有节点i（即i必须在j之后）
			}
		}
	}
}

// GTSP相关函数实现
void read_data::define_gtsp(){
	// 分配GTSP特有的数据结构内存
	precedenceConstraints = new int *[num_v];//先后约束矩阵
	sameCluster = new int *[num_v];//“是否同簇”矩阵
	for (int i=0;i<num_v;i++){
		precedenceConstraints[i] = new int [num_v];
		sameCluster[i] = new int [num_v];
		for (int j=0;j<num_v;j++){
			precedenceConstraints[i][j] = 0;
			sameCluster[i][j] = 0;
		}
	}
	nodeGroup = std::vector<int>(num_v, -1);  // 初始化为-1
	groupNodes = std::vector<std::vector<int>>(num_groups + 1);  // 簇编号从1开始
}

void read_data::read_gtsp(std::string pathInstance, std::string pathSolution, int nump, double bestDis, int isOptimal, int timeLimit, int iterLimit, int seed){
	//输入信息
	this->timeLimit = timeLimit;
	this->iterLimit = iterLimit;
	this->num_p = nump;//p=1
	this->bestDis = bestDis;
	this->isOptimal = isOptimal;
	this->isGTSP = true;  

	this->pathSolution = pathSolution;
	this->pathInstance = pathInstance;

	
	// 读取输入文件
	std::string content, content2;
	std::ifstream inputFile(pathInstance);
	
	if (!inputFile.is_open()){
		std::cout<<"Cannot open input file: "<<pathInstance<<std::endl;
		exit(0);
	}
	
	// 第一遍：读取基本信息
	while (inputFile >> content) {
		if (content == "DIMENSION" || content == "DIMENSION:"){
			if (content == "DIMENSION") inputFile >> content2;
			inputFile >> num_v;
		}
		else if (content == "GROUPS" || content == "GROUPS:"){
			if (content == "GROUPS") inputFile >> content2;
			inputFile >> num_groups;
		}
		else if (content == "EDGE_WEIGHT_TYPE" || content == "EDGE_WEIGHT_TYPE:"){
			if (content == "EDGE_WEIGHT_TYPE") inputFile >> content2;
			inputFile >> typeGraph;
		}
		else if (content == "EDGE_WEIGHT_FORMAT" || content == "EDGE_WEIGHT_FORMAT:"){
			if (content == "EDGE_WEIGHT_FORMAT") inputFile >> content2;
			inputFile >> matrix_row;
		}
		else if (content == "NODE_WEIGHT_SECTION"){//// 跳过节点权重部分（全0）
			for (int i=0; i<num_v; i++){
				double temp;
				inputFile >> temp;
			}
		}
		else if (content == "EDGE_WEIGHT_SECTION"){
			break;  // 找到距离矩阵部分
		}
	}
	
	std::cout<<"GTSP Problem: nodes="<<num_v<<", clusters="<<num_groups<<", p="<<num_p<<std::endl;
	
	// 分配内存
	define();
	define_gtsp();
	
	// 读取距离矩阵
	std::cout<<"Reading distance matrix..."<<std::endl;
	for (int i=0; i<num_v; i++){
		for (int j=0; j<num_v; j++){
			inputFile >> D[i][j];
			
			// 只识别-1（优先级约束）
			if (D[i][j] < -0.5){  // 约等于-1
				precedenceConstraints[i][j] = -1;  // i必须在j之后
				D[i][j] = Max;  // 设为无穷大，避免在搜索中使用
			}
		}
	}
	
	// 读取NODE_GROUP_SECTION
	std::cout<<"Reading node grouping information..."<<std::endl;
	while (inputFile >> content){
		if (content == "NODE_GROUP_SECTION"){
			for (int g=1; g<=num_groups; g++){
				int groupId;
				inputFile >> groupId;  // 读取簇编号
				
				int nodeId;
				while (inputFile >> nodeId){
					if (nodeId == -1) break;  // -1表示该簇结束
					nodeGroup[nodeId - 1] = groupId;  // 节点编号从1开始，数组从0开始
					groupNodes[groupId].push_back(nodeId - 1);
				}
				
				std::cout<<"Cluster "<<groupId<<" has "<<groupNodes[groupId].size()<<" nodes: ";
				for (int node : groupNodes[groupId]){
					std::cout<<(node+1)<<" ";
				}
				std::cout<<std::endl;
			}
			break;
		}
	}
	
	// 根据NODE_GROUP_SECTION信息标记同簇节点，并将同簇边设为无穷大
	std::cout<<"Marking same-cluster pairs..."<<std::endl;
	int sameClusterCount = 0;
	for (int g=1; g<=num_groups; g++){
		// 对于每个簇，标记簇内所有节点对为同簇
		for (size_t i=0; i<groupNodes[g].size(); i++){
			for (size_t j=i+1; j<groupNodes[g].size(); j++){
				int node1 = groupNodes[g][i];
				int node2 = groupNodes[g][j];
				sameCluster[node1][node2] = 1;
				sameCluster[node2][node1] = 1;
				// 将同簇节点间的距离设为无穷大（GTSP约束：同簇节点不能直接相连）
				D[node1][node2] = Max;
				D[node2][node1] = Max;
				sameClusterCount++;
			}
		}
	}
	std::cout<<"Marked "<<sameClusterCount<<" same-cluster pairs"<<std::endl;
	
	// 读取START_GROUP_SECTION
	while (inputFile >> content){
		if (content == "START_GROUP_SECTION"){
			inputFile >> startGroup;
			std::cout<<"Start cluster: "<<startGroup<<std::endl;
			break;
		}
	}
	
	inputFile.close();
	
	// 构建稀疏图
	std::cout<<"Building sparse graph..."<<std::endl;
	std::vector < std::set < int > > setCorrelatedVertices = std::vector < std::set <int> >(num_v);
	std::vector < std::pair <double, int> > orderProximity;
	
	for (int i = 0; i < num_v; i++){
		orderProximity.clear();
		for (int j = 0; j < num_v; j++){
			if (i != j && D[i][j] < Max - 1) {  // 排除无穷大的边
				orderProximity.push_back(std::pair <double, int>(D[i][j], j));
			}
		}
		sort(orderProximity.begin(), orderProximity.end());
		
		int numToAdd = std::min<int>(alpha, (int)orderProximity.size());
		for (int j = 0; j < numToAdd; j++){
			setCorrelatedVertices[i].insert(orderProximity[j].second);
			setCorrelatedVertices[orderProximity[j].second].insert(i);
		}
		
		// 存储按距离排序的所有邻居
		for (int j=0; j < (int)orderProximity.size(); j++)
			nearCity[i].push_back(orderProximity[j].second);
	}
	
	// 填充邻接表
	for (int i = 0; i < num_v; i++)
		for (int x : setCorrelatedVertices[i])
			edge_node[i].push_back(x);
	
	// 填充邻接矩阵
	for (int i=0; i<num_v; i++)
		for (int j=0; j<(int)edge_node[i].size(); j++)
			correctedEdge[i][edge_node[i][j]] = 1;
	
	// 计算平均邻居数
	int totalNeighbors = 0;
	for (int i = 0; i < num_v; i++) {
		totalNeighbors += edge_node[i].size();
	}
	double avgNeighbors = (double)totalNeighbors / num_v;
	std::cout << "Average neighbors per node: " << avgNeighbors 
				  << " (alpha=" << alpha << ")" << std::endl;
	
	std::cout<<"GTSP problem loaded successfully!"<<std::endl;
	std::cout<<"- Total "<<num_groups<<" clusters"<<std::endl;
	std::cout<<"- Need to select "<<num_p<<" p-centers"<<std::endl;
	std::cout<<"- Each cluster must select exactly one node"<<std::endl;
	
	// 统计约束数量
	int numConstraints = 0;
	for (int i=0; i<num_v; i++){
		for (int j=0; j<num_v; j++){
			if (precedenceConstraints[i][j] == -1)
				numConstraints++;
		}
	}
	std::cout<<"- Total "<<numConstraints<<" precedence constraints"<<std::endl;
	
	// 预处理约束数据
	preprocessPrecedenceConstraints();
	std::cout<<"- Precedence constraints preprocessed"<<std::endl;
}

