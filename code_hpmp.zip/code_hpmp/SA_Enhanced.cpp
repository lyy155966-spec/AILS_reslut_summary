#include "SA_Enhanced.h"
#include "MyLS.h"
#include "basic.h"
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <chrono>
#include <algorithm>
#include <set>

SA_Enhanced::SA_Enhanced(read_data* data) {
    this->data = data;
    this->num_v = data->num_v;
    this->num_groups = data->num_groups;
    
    // Shaw removal参数初始化
    cityRank.resize(num_v);
    determinePara = 6.0;  // Shaw removal标准参数
    
    precedenceList.clear();
    
    for (int i = 0; i < num_v; i++) {
        for (int j = 0; j < num_v; j++) {
            if (data->precedenceConstraints[i][j] == -1) {
                // precedenceConstraints[i][j]=-1 表示节点i必须在节点j之后
                precedenceList.push_back({i, j});
            }
        }
    }
    
    // 初始化SA参数
    this->temperature = 100.0;  // 将在第一次使用时自动调整
    this->initialTemperature = 100.0;
    this->coolingRate = 0.995;
    this->lastTemperature = 0.00001;  // 最终温度
    this->iterationCount = 0;
    this->segmentCount = 0;
    this->lastUsedDestroy = 0;
    this->lastUsedRepair = 0;
    this->lastUsedOperator = 0;
    
    // 自适应学习参数
    this->learningRate = 0.1;           // 学习率
    this->updateInterval = 50;          // 每50次迭代更新一次权重，视作一个 episode
    
    // 温度控制参数
    this->acceptanceProbability = 0.7;  // 目标接受概率
    this->temperatureParameter = 0.35;  // 控制初温和解质量之间的比例系数
    
    // 三解管理初始化
    this->globalBest = nullptr;
    this->localBest = nullptr;
    
    // 初始化操作符权重
    initializeWeights();
}

SA_Enhanced::~SA_Enhanced() {
}

void SA_Enhanced::run(Individual* currentSol, MyLS* ls, double& bestDistance, int& bestFoundAtIteration, int& finalIteration, double stopTemperature, int episodeLength, int restartInterval) {
    int segment = 0;                    // 段计数器

    // 初始化统计量
    bestFoundAtIteration = 0;       // 记录最优解是在第几次迭代找到的
    finalIteration = 0;             // 最终迭代次数
    
    // 初始化三解管理
    if (globalBest == nullptr) {
        globalBest = new Individual();
        globalBest->define(data);
    }
    if (localBest == nullptr) {
        localBest = new Individual();
        localBest->define(data);
    }
    
    // 复制当前解作为初始的最优解
    globalBest->copyFrom(currentSol);
    localBest->copyFrom(currentSol);
    bestDistance = currentSol->dis;
    
    // 时间记录
    auto segmentStartTime = std::chrono::high_resolution_clock::now();
    auto algorithmStartTime = segmentStartTime;

    std::cout << "Starting SA loop with initial T=" << temperature << ", stop at T=" << stopTemperature << std::endl;
    std::cout << "SA initialized: Global=" << globalBest->dis << ", Local=" << localBest->dis << std::endl;

    for (int iter = 1; ; iter++) {  // 无限循环，只依赖温度终止
        finalIteration = iter;  // 记录当前迭代次数
        double oldDistance = currentSol->dis;
        
        perturb(currentSol);
        
        // 使用传入的局部搜索算法
        ls->local_search_run(currentSol);
        // 三解SA接受准则
        bool accepted = acceptSolution(currentSol, localBest, globalBest);
        

        // 检查是否找到新的全局最优解
        if (globalBest->dis < bestDistance - 0.001) {
            double improvement = bestDistance - globalBest->dis;
            bestDistance = globalBest->dis;
            bestFoundAtIteration = iter;

            std::cout << "Iter " << iter << ": New GLOBAL best = " << bestDistance << " (Op: " << getLastUsedOperator() << ", T: " << getTemperature() << ")" << std::endl;
        }


        // std::cout << "Iter " << iter <<std::endl;
        // 每次迭代：持续冷却
        updateTemperature();

        // 温度终止检查（最高优先级）
        if (getTemperature() < stopTemperature) {
            std::cout << "Algorithm terminated: Temperature too low (T=" << getTemperature() << ")" << std::endl;
            std::cout << "Final iteration: " << iter << std::endl;
            break;  // 退出主循环
        }

        // 每episode：更新权重和segment
        if (iter % episodeLength == 0) {
            segment++;
            
            // 计算本segment用时
            auto segmentEndTime = std::chrono::high_resolution_clock::now();
            auto segmentDuration = std::chrono::duration_cast<std::chrono::milliseconds>(segmentEndTime - segmentStartTime);
            double segmentSeconds = segmentDuration.count() / 1000.0;
            // 计算总用时
            auto totalDuration = std::chrono::duration_cast<std::chrono::milliseconds>(segmentEndTime - algorithmStartTime);
            double totalSeconds = totalDuration.count() / 1000.0;

            // 定期完全重启（未使用）
            if (segment % restartInterval == 0) {
                // 从全局最优解重启
                currentSol->copyFrom(globalBest);
                localBest->copyFrom(globalBest);

                // 完全重启：重新计算温度、冷却率、重置权重
                periodicRestart(globalBest->dis, restartInterval, episodeLength);

                std::cout << "Segment " << segment << ": PERIODIC restart (reset T, cooling_rate, weights) "<< "[Time: " << segmentSeconds << "s, Total: " << totalSeconds << "s]" << std::endl;
            }
            else {
                // 非重启时：自适应更新权重
                updateOperatorWeights();
                if (segment % 100 == 0) {  // 只在每10个segment输出一次
                    std::cout << "Segment " << segment << ": Updated operator weights (T=" << getTemperature() << ") " << "[Time: " << segmentSeconds << "s, Total: " << totalSeconds << "s]" << std::endl;
                }
            }
            
            // 重置segment计时器
            segmentStartTime = std::chrono::high_resolution_clock::now();
        }

        //每1000次迭代报告进度
        if (iter % 1000 == 0) {  // 减少输出频率但不要太少，确保能看到进展
            std::cout << "Iter " << iter << ": Current = " << currentSol->dis << ", Local = " << localBest->dis << ", Global = " << globalBest->dis << ", T = " << getTemperature() << std::endl;
        }
    }
    
}

void SA_Enhanced::initializeWeights() {
    // 初始化破坏算子权重
    for (int i = 0; i < NUM_DESTROY_OPERATORS; i++) {
        destroyWeights[i] = 1.0;
        destroyScores[i] = 0.0;
        destroyUsage[i] = 0;
        destroyCumulativeProb[i] = 0.0;
    }
    
    // 初始化修复算子权重
    for (int i = 0; i < NUM_REPAIR_OPERATORS; i++) {
        repairWeights[i] = 1.0;
        repairScores[i] = 0.0;
        repairUsage[i] = 0;
        repairCumulativeProb[i] = 0.0;
    }
    
    updateDestroyCumulativeProb();
    updateRepairCumulativeProb();
}

void SA_Enhanced::updateDestroyCumulativeProb() {
    double totalWeight = 0.0;
    for (int i = 0; i < NUM_DESTROY_OPERATORS; i++) {
        totalWeight += destroyWeights[i];
    }
    
    if (totalWeight > 0) {
        double cumulative = 0.0;
        for (int i = 0; i < NUM_DESTROY_OPERATORS; i++) {
            cumulative += destroyWeights[i] / totalWeight;
            destroyCumulativeProb[i] = cumulative;
        }
    } else {
        for (int i = 0; i < NUM_DESTROY_OPERATORS; i++) {
            destroyCumulativeProb[i] = (double)(i + 1) / NUM_DESTROY_OPERATORS;
        }
    }
}

void SA_Enhanced::updateRepairCumulativeProb() {
    double totalWeight = 0.0;
    for (int i = 0; i < NUM_REPAIR_OPERATORS; i++) {
        totalWeight += repairWeights[i];
    }
    
    if (totalWeight > 0) {
        double cumulative = 0.0;
        for (int i = 0; i < NUM_REPAIR_OPERATORS; i++) {
            cumulative += repairWeights[i] / totalWeight;
            repairCumulativeProb[i] = cumulative;
        }
    } else {
        for (int i = 0; i < NUM_REPAIR_OPERATORS; i++) {
            repairCumulativeProb[i] = (double)(i + 1) / NUM_REPAIR_OPERATORS;
        }
    }
}

void SA_Enhanced::initializeTemperature(Individual* solution) {
    // 基于初始解质量自动设置温度
    double solutionCost = solution->dis;
    double logAcceptProb = std::log(acceptanceProbability);
    this->initialTemperature = -temperatureParameter * solutionCost / logAcceptProb;
    this->temperature = this->initialTemperature;
    
    // 计算冷却率（基于更新间隔）
    double finalTemperature = 0.000005;//预期最终温度但不是最终温度，而是为了控制冷却速度
    double steps = updateInterval * 2000; // 预期运行步数50*2000=100000次
    this->coolingRate = std::pow(finalTemperature / initialTemperature, 1.0 / steps);

}

void SA_Enhanced::perturb(Individual* solution) {
    // 保存扰动前的状态，用于回滚
    Individual backup;
    backup.define(data);
    backup.copyFrom(solution);
    
//  // 验证备份解的完整性
    // std::vector<int> clusterCount(num_groups + 1, 0);
    // Node* current = &backup.client[backup.start[0]];
    // bool isFirst = true;
    // while (current->cour != backup.start[0] || isFirst) {
    //     int cluster = data->nodeGroup[current->cour];
    //     clusterCount[cluster]++;
    //     current = current->next;
    //     isFirst = false;
    // }
    
    // bool backupOK = true;
    // for (int g = 1; g <= num_groups; g++) {
    //     if (clusterCount[g] != 1) {
    //         backupOK = false;
            
    //         break;
    //     }
    // }
    
    // if (!backupOK) {
        
    //     return; // 不执行扰动，保持原解不变
    // }
    
    int destroyId = selectDestroyOperator();
    lastUsedDestroy = destroyId;
    
    std::vector<int> removedNodes = executeDestroyOperator(destroyId, solution);
    destroyUsage[destroyId]++;
    
    int repairId = selectRepairOperator();
    lastUsedRepair = repairId;
    
    executeRepairOperator(repairId, solution, removedNodes);
    repairUsage[repairId]++;
    
    lastUsedOperator = destroyId * NUM_REPAIR_OPERATORS + repairId;
    
    solution->evaluationDis();
    
    // 检查修复后的解是否满足所有约束
    // 1. 检查簇约束：每个簇必须恰好有一个节点
    std::vector<int> finalClusterCount(num_groups + 1, 0);
    Node* finalCurrent = &solution->client[solution->start[0]];
    bool finalIsFirst = true;
    while (finalCurrent->cour != solution->start[0] || finalIsFirst) {
        int cluster = data->nodeGroup[finalCurrent->cour];
        finalClusterCount[cluster]++;
        finalCurrent = finalCurrent->next;
        finalIsFirst = false;
    }
    
    bool clusterOK = true;
    for (int g = 1; g <= num_groups; g++) {
        if (finalClusterCount[g] != 1) {
            clusterOK = false;
            break;
        }
    }
    
    
    // 如果约束违反，回滚到扰动前的状态
    if (!clusterOK) {
        //std::cout << "[SA WARNING] Constraint violation detected, rolling back. ClusterOK=" << clusterOK << std::endl;
        solution->copyFrom(&backup);
        solution->evaluationDis();
        
        // 验证回滚后的解
        std::fill(finalClusterCount.begin(), finalClusterCount.end(), 0);
        finalCurrent = &solution->client[solution->start[0]];
        finalIsFirst = true;
        while (finalCurrent->cour != solution->start[0] || finalIsFirst) {
            int cluster = data->nodeGroup[finalCurrent->cour];
            finalClusterCount[cluster]++;
            finalCurrent = finalCurrent->next;
            finalIsFirst = false;
        }
        
        bool rollbackOK = true;
        for (int g = 1; g <= num_groups; g++) {
            if (finalClusterCount[g] != 1) {
                rollbackOK = false;
                break;
            }
        }
    }
}

bool SA_Enhanced::acceptSolution(Individual* current, Individual* localBest, Individual* globalBest) {
    // 三层接受准则
    
    // 第1层：全局最优解更新
    if (current->dis + 1e-7 < globalBest->dis) {
        globalBest->copyFrom(current);
        localBest->copyFrom(current);
        recordOperatorSuccess(lastUsedDestroy, lastUsedRepair, GLOBAL_BEST);
        return true;
    }
    
    // 第2层：局部最优解更新
    if (current->dis + 1e-7 < localBest->dis) {
        localBest->copyFrom(current);
        recordOperatorSuccess(lastUsedDestroy, lastUsedRepair, LOCAL_IMPROVE);
        return true;
    }
    
    // 第3层：模拟退火概率接受
    if (current->dis - 1e-7 > localBest->dis) {
        if (temperature <= 1e-10) {
            current->copyFrom(localBest);
            return false;
        }
        
        double delta = current->dis - localBest->dis;
        double probability = exp(-delta / temperature);
        double random = (double)rand() / RAND_MAX;
        
        if (random < probability) {
            localBest->copyFrom(current);
            recordOperatorSuccess(lastUsedDestroy, lastUsedRepair, ACCEPT_ONLY);
            return true;
        } else {
            current->copyFrom(localBest);
            return false;
        }
    }
    
    return true;
}

void SA_Enhanced::updateTemperature() {
    temperature *= coolingRate;
    iterationCount++;
    
    // 防止温度过低
    if (temperature < 0.000000001) {
        temperature = 0.000000001;//
    }
}

void SA_Enhanced::updateOperatorWeights() {
    // 更新破坏算子权重
    for (int i = 0; i < NUM_DESTROY_OPERATORS; i++) {
        if (destroyUsage[i] > 0) {
            double avgScore = destroyScores[i] / destroyUsage[i];
            destroyWeights[i] = (1.0 - learningRate) * destroyWeights[i] + learningRate * avgScore;
            
            if (destroyWeights[i] < 0.1) {
                destroyWeights[i] = 0.1;
            }
            
            destroyScores[i] = 0.0;
            destroyUsage[i] = 0;
        }
    }
    
    // 更新修复算子权重
    for (int i = 0; i < NUM_REPAIR_OPERATORS; i++) {
        if (repairUsage[i] > 0) {
            double avgScore = repairScores[i] / repairUsage[i];
            repairWeights[i] = (1.0 - learningRate) * repairWeights[i] + learningRate * avgScore;
            
            if (repairWeights[i] < 0.1) {
                repairWeights[i] = 0.1;
            }
            
            repairScores[i] = 0.0;
            repairUsage[i] = 0;
        }
    }
    
    updateDestroyCumulativeProb();
    updateRepairCumulativeProb();
}

void SA_Enhanced::recordOperatorSuccess(int destroyId, int repairId, int rewardType) {
    int reward = 0;
    switch (rewardType) {
        case GLOBAL_BEST:
            reward = REWARD_GLOBAL_BEST;  // 10
            break;
        case LOCAL_IMPROVE:
            reward = REWARD_LOCAL_IMPROVE;  // 5
            break;
        case ACCEPT_ONLY:
            reward = REWARD_ACCEPT;  // 3
            break;
    }
    
    // 同时奖励破坏和修复算子
    if (destroyId >= 0 && destroyId < NUM_DESTROY_OPERATORS) {
        destroyScores[destroyId] += reward;
    }
    if (repairId >= 0 && repairId < NUM_REPAIR_OPERATORS) {
        repairScores[repairId] += reward;
    }
}
// 算子选择

int SA_Enhanced::selectDestroyOperator() {
    double random = (double)rand() / RAND_MAX;
    
    for (int i = 0; i < NUM_DESTROY_OPERATORS; i++) {
        if (random <= destroyCumulativeProb[i]) {
            return i;
        }
    }
    
    return NUM_DESTROY_OPERATORS - 1;
}

int SA_Enhanced::selectRepairOperator() {
    double random = (double)rand() / RAND_MAX;
    
    for (int i = 0; i < NUM_REPAIR_OPERATORS; i++) {
        if (random <= repairCumulativeProb[i]) {
            return i;
        }
    }
    
    return NUM_REPAIR_OPERATORS - 1;
}

std::vector<int> SA_Enhanced::executeDestroyOperator(int operatorId, Individual* solution) {
    switch (operatorId) {
        case 0:
            return randomDestroy(solution, 0.38);
        case 1:
            return shawDestroy(solution, 0.38);
        case 2:
            return worstDestroy(solution, 0.38);
        case 3:
            return precedenceDestroy(solution, 0.38);
        default:
            return randomDestroy(solution, 0.38);
    }
}

void SA_Enhanced::executeRepairOperator(int operatorId, Individual* solution, std::vector<int>& removedNodes) {
    switch (operatorId) {
        case 0:
            greedyRepair(solution, removedNodes);
            break;
        case 1:
            greedyBlinkRepair(solution, removedNodes);
            break;
        case 2:
            regretRepair(solution, removedNodes);
            break;
        case 3:
            randomRepair(solution, removedNodes);
            break;
        case 4:
            clusterSwapRepair(solution, removedNodes);
            break;
        default:
            greedyRepair(solution, removedNodes);
            break;
    }
}

// 直接从链表中移除节点
void SA_Enhanced::removeNodeFromList(Individual* solution, int nodeIndex) {
    Node* p = &solution->client[nodeIndex];
    Node* pre = p->pre;
    Node* next = p->next;
    
    pre->next = next;
    next->pre = pre;
    p->pre = NULL;
    p->next = NULL;
    p->route = NULL;
}

// 直接在链表中插入节点
void SA_Enhanced::insertNodeAfter(Individual* solution, int nodeToInsert, Node* afterThis) {
    Node* nodeU = &solution->client[nodeToInsert];
    Node* nextNode = afterThis->next;
    
    // 插入节点
    afterThis->next = nodeU;
    nodeU->pre = afterThis;
    nodeU->next = nextNode;
    nextNode->pre = nodeU;
    nodeU->route = afterThis->route;
}

// 增量式约束检查：检查插入节点后是否满足约束
bool SA_Enhanced::checkNodeConstraints(Individual* solution, int node) {
    Node* current = &solution->client[solution->start[0]];
    bool isFirst = true;
    bool nodeFound = false;
    
    while (current->cour != solution->start[0] || isFirst) {
        if (current->cour == node) {
            nodeFound = true;
        }
        else if (!nodeFound) {
            // 还没遇到node，current在node之前
            // 检查：如果current必须在node之后 (precedenceConstraints[current][node] == -1)，则违反
            if (data->precedenceConstraints[current->cour][node] == -1) return false;
            //             // 还没遇到node，检查是否遇到了必须在node之后的节点
            // for (int i : data->mustBefore[node]) {
            //     if (current->cour == i) return false;  // i必须在node之后，但i出现在node之前
            // }
        }
        else {
            // 已经遇到node，current在node之后
            // 检查：如果node必须在current之后 (precedenceConstraints[node][current] == -1)，则违反
            if (data->precedenceConstraints[node][current->cour] == -1) return false;
            //             // 已经遇到node，检查是否遇到了必须在node之前的节点
            // for (int j : data->mustAfter[node]) {
            //     if (current->cour == j) return false;  // node必须在j之后，但j出现在node之后
            // }
        }
        
        current = current->next;
        isFirst = false;
    }
    
    return true;
}

// 计算在指定节点之后插入的成本
double SA_Enhanced::calculateInsertionCost(Node* afterThis, int nodeToInsert) {
    int prev = afterThis->cour;
    int next = afterThis->next->cour;
    
    // 插入成本 = 新边 - 旧边
    double cost = data->D[prev][nodeToInsert] + data->D[nodeToInsert][next] - data->D[prev][next];
    return cost;
}

std::vector<int> SA_Enhanced::randomDestroy(Individual* solution, double ratio) {
    std::vector<int> nodesList, removedNodes;
    Node* current = &solution->client[solution->start[0]];
    bool isFirst = true;
    
    while (current->cour != solution->start[0] || isFirst) {
        if (current->cour != 0) {
            nodesList.push_back(current->cour);
        }
        current = current->next;
        isFirst = false;
    }
    
    int numToRemove = (int)(nodesList.size() * ratio);
    if (numToRemove < 1) numToRemove = 1;
    if (numToRemove >= (int)nodesList.size()) numToRemove = nodesList.size() - 1;
    
    std::random_shuffle(nodesList.begin(), nodesList.end());
    
    for (int i = 0; i < numToRemove; i++) {
        removedNodes.push_back(nodesList[i]);
        removeNodeFromList(solution, nodesList[i]);
    }
    
    int routeIndex = 0;
    solution->updateRouteInfor(routeIndex);
    return removedNodes;
}

std::vector<int> SA_Enhanced::shawDestroy(Individual* solution, double ratio) {
    // 复用randomDestroy的结构，改变选点逻辑
    std::vector<int> nodesList, removedNodes;
    Node* current = &solution->client[solution->start[0]];
    bool isFirst = true;
    
    // 第一步：收集所有节点
    while (current->cour != solution->start[0] || isFirst) {
        if (current->cour != 0) {
            nodesList.push_back(current->cour);
        }
        current = current->next;
        isFirst = false;
    }
    
    // 第二步：计算要移除的数量
    int numToRemove = (int)(nodesList.size() * ratio);
    if (numToRemove < 1) numToRemove = 1;
    if (numToRemove >= (int)nodesList.size()) numToRemove = nodesList.size() - 1;
    
    // 第三步：使用Shaw策略对nodesList排序
    // 从nodesList中随机选择一个种子节点
    int seedIdx = rand() % nodesList.size();
    int seed = nodesList[seedIdx];
    
    // 按照与种子节点的距离排序
    std::vector<std::pair<double, int>> distanceToSeed;
    for (int node : nodesList) {
        double dist = data->D[seed][node];
        distanceToSeed.push_back({dist, node});
    }
    std::sort(distanceToSeed.begin(), distanceToSeed.end());
    
    // 使用Shaw removal的随机化选择：优先选择距离近的节点
    std::vector<int> selectedNodes;
    std::vector<bool> selected(distanceToSeed.size(), false);
    
    while ((int)selectedNodes.size() < numToRemove) {
        double y = double(rand() % 10000) / 10000.0;
        int rank = int(pow(y, determinePara) * distanceToSeed.size());
        
        // 找到第rank个未选择的节点
        int count = 0;
        for (int i = 0; i < (int)distanceToSeed.size(); i++) {
            if (!selected[i]) {
                if (count == rank) {
                    selectedNodes.push_back(distanceToSeed[i].second);
                    selected[i] = true;
                    break;
                }
                count++;
            }
        }
    }
    
    // 第四步：移除选中的节点
    for (int i = 0; i < numToRemove; i++) {
        removedNodes.push_back(selectedNodes[i]);
        removeNodeFromList(solution, selectedNodes[i]);
    }
    
    // 第五步：更新路由信息
    int routeIndex = 0;
    solution->updateRouteInfor(routeIndex);
    return removedNodes;
}

std::vector<int> SA_Enhanced::worstDestroy(Individual* solution, double ratio) {
    std::vector<int> nodesList, removedNodes;
    Node* current = &solution->client[solution->start[0]];
    bool isFirst = true;
    
    // 第一步：收集所有节点
    while (current->cour != solution->start[0] || isFirst) {
        if (current->cour != 0) {
            nodesList.push_back(current->cour);
        }
        current = current->next;
        isFirst = false;
    }
    
    // 第二步：计算要移除的数量
    int numToRemove = (int)(nodesList.size() * ratio);
    if (numToRemove < 1) numToRemove = 1;
    if (numToRemove >= (int)nodesList.size()) numToRemove = nodesList.size() - 1;
    
    // 第三步：使用Worst策略计算每个节点的移除代价
    std::vector<std::pair<double, int>> nodeCost;
    for (int node : nodesList) {
        Node* p = &solution->client[node];
        int prevIndex = p->pre->cour;
        int nextIndex = p->next->cour;
        
        // saving = 移除该节点后节省的距离（越大说明该节点位置越差）
        double saving = data->D[prevIndex][node] + data->D[node][nextIndex] - data->D[prevIndex][nextIndex];
        nodeCost.push_back({-saving, node});  // 负号使得排序后最差的节点在前面
    }
    std::sort(nodeCost.begin(), nodeCost.end());
    
    // 使用Worst removal的随机化选择：优先选择代价高（位置差）的节点
    std::vector<int> selectedNodes;
    std::vector<bool> selected(nodeCost.size(), false);
    
    while ((int)selectedNodes.size() < numToRemove) {
        double y = double(rand() % 10000) / 10000.0;
        int rank = int(pow(y, determinePara) * nodeCost.size());
        
        // 找到第rank个未选择的节点
        int count = 0;
        for (int i = 0; i < (int)nodeCost.size(); i++) {
            if (!selected[i]) {
                if (count == rank) {
                    selectedNodes.push_back(nodeCost[i].second);
                    selected[i] = true;
                    break;
                }
                count++;
            }
        }
    }
    
    // 第四步：移除选中的节点（与randomDestroy完全相同）
    for (int i = 0; i < numToRemove; i++) {
        removedNodes.push_back(selectedNodes[i]);
        removeNodeFromList(solution, selectedNodes[i]);
    }
    
    // 第五步：更新路由信息（与randomDestroy完全相同）
    int routeIndex = 0;
    solution->updateRouteInfor(routeIndex);
    return removedNodes;
}

std::vector<int> SA_Enhanced::precedenceDestroy(Individual* solution, double ratio) {
    return randomDestroy(solution, ratio);
}

void SA_Enhanced::greedyRepair(Individual* solution, std::vector<int>& removedNodes) {
    // 按优先级约束排序：依赖少的节点先插入
    std::vector<std::pair<int, int>> nodeWithPriority;
    for (int node : removedNodes) {
        int precedenceCount = 0;
        for (int otherNode : removedNodes) {
            if (data->precedenceConstraints[node][otherNode] == -1) {
                precedenceCount++;
            }
        }
        nodeWithPriority.push_back({precedenceCount, node});
    }
    std::sort(nodeWithPriority.begin(), nodeWithPriority.end());
    
    for (auto& pair : nodeWithPriority) {
        int node = pair.second;
        Node* bestPos = NULL;
        double bestCost = 1e30;
        
        // 遍历所有位置寻找最优插入点
        Node* current = &solution->client[solution->start[0]];
        bool isFirst = true;
        
        while (current->cour != solution->start[0] || isFirst) {
            Node* nextNode = current->next;
            double cost = data->D[current->cour][node] + data->D[node][nextNode->cour] 
                        - data->D[current->cour][nextNode->cour];
            
            if (cost < bestCost) {
                insertNodeAfter(solution, node, current);
                bool satisfies = checkNodeConstraints(solution, node);
                removeNodeFromList(solution, node);
                
                if (satisfies) {
                    bestCost = cost;
                    bestPos = current;
                }
            }
            
            current = nextNode;
            isFirst = false;
        }
        
        if (bestPos != NULL) {
            insertNodeAfter(solution, node, bestPos);
        }
    }
    
    int routeIndex = 0;
    solution->updateRouteInfor(routeIndex);
}

// 2. 带随机性的贪婪修复（与greedyRepair结构相同，但有概率接受次优位置）
void SA_Enhanced::greedyBlinkRepair(Individual* solution, std::vector<int>& removedNodes) {
    double blinkProb = 0.1;  // 10%概率跳过当前最优
    
    std::vector<std::pair<int, int>> nodeWithPriority;
    for (int node : removedNodes) {
        int precedenceCount = 0;
        for (int otherNode : removedNodes) {
            if (data->precedenceConstraints[node][otherNode] == -1) {
                precedenceCount++;
            }
        }
        nodeWithPriority.push_back({precedenceCount, node});
    }
    std::sort(nodeWithPriority.begin(), nodeWithPriority.end());
    
    for (auto& pair : nodeWithPriority) {
        int node = pair.second;
        Node* bestPos = NULL;
        double bestCost = 1e30;
        
        Node* current = &solution->client[solution->start[0]];
        bool isFirst = true;
        
        while (current->cour != solution->start[0] || isFirst) {
            Node* nextNode = current->next;
            double cost = data->D[current->cour][node] + data->D[node][nextNode->cour] 
                        - data->D[current->cour][nextNode->cour];
            
            // blink: 有概率跳过更优的位置
            if (cost < bestCost && (double)rand() / RAND_MAX > blinkProb) {
                insertNodeAfter(solution, node, current);
                bool satisfies = checkNodeConstraints(solution, node);
                removeNodeFromList(solution, node);
                
                if (satisfies) {
                    bestCost = cost;
                    bestPos = current;
                }
            }
            
            current = nextNode;
            isFirst = false;
        }
        
        if (bestPos != NULL) {
            insertNodeAfter(solution, node, bestPos);
        }
    }
    
    int routeIndex = 0;
    solution->updateRouteInfor(routeIndex);
}

// 3. 后悔修复
void SA_Enhanced::regretRepair(Individual* solution, std::vector<int>& removedNodes) {
    // 按优先级约束排序
    std::vector<std::pair<int, int>> nodeWithPriority;
    for (int node : removedNodes) {
        int precedenceCount = 0;
        for (int otherNode : removedNodes) {
            if (data->precedenceConstraints[node][otherNode] == -1) {
                precedenceCount++;
            }
        }
        nodeWithPriority.push_back({precedenceCount, node});
    }
    std::sort(nodeWithPriority.begin(), nodeWithPriority.end());
    
    for (auto& pair : nodeWithPriority) {
        int node = pair.second;
        
        // 收集所有满足约束的位置及其成本
        std::vector<std::pair<double, Node*>> feasiblePositions;
        
        Node* current = &solution->client[solution->start[0]];
        bool isFirst = true;
        
        while (current->cour != solution->start[0] || isFirst) {
            Node* nextNode = current->next;
            double cost = data->D[current->cour][node] + data->D[node][nextNode->cour] 
                        - data->D[current->cour][nextNode->cour];
            
            insertNodeAfter(solution, node, current);
            bool satisfies = checkNodeConstraints(solution, node);
            removeNodeFromList(solution, node);
            
            if (satisfies) {
                feasiblePositions.push_back({cost, current});
            }
            
            current = nextNode;
            isFirst = false;
        }
        
        Node* selectedPos = NULL;
        
        if (feasiblePositions.size() >= 2) {
            // 按成本排序，选择次优位置
            std::sort(feasiblePositions.begin(), feasiblePositions.end());
            selectedPos = feasiblePositions[1].second;
        } else if (feasiblePositions.size() == 1) {
            selectedPos = feasiblePositions[0].second;
        }
        
        if (selectedPos != NULL) {
            insertNodeAfter(solution, node, selectedPos);
        }
    }
    
    int routeIndex = 0;
    solution->updateRouteInfor(routeIndex);
}

// 4. 随机修复
void SA_Enhanced::randomRepair(Individual* solution, std::vector<int>& removedNodes) {
    // 按优先级约束排序
    std::vector<std::pair<int, int>> nodeWithPriority;
    for (int node : removedNodes) {
        int precedenceCount = 0;
        for (int otherNode : removedNodes) {
            if (data->precedenceConstraints[node][otherNode] == -1) {
                precedenceCount++;
            }
        }
        nodeWithPriority.push_back({precedenceCount, node});
    }
    std::sort(nodeWithPriority.begin(), nodeWithPriority.end());
    
    for (auto& pair : nodeWithPriority) {
        int node = pair.second;
        std::vector<Node*> feasiblePositions;
        
        Node* current = &solution->client[solution->start[0]];
        bool isFirst = true;
        
        while (current->cour != solution->start[0] || isFirst) {
            Node* nextNode = current->next;
            
            insertNodeAfter(solution, node, current);
            bool satisfies = checkNodeConstraints(solution, node);
            removeNodeFromList(solution, node);
            
            if (satisfies) {
                feasiblePositions.push_back(current);
            }
            
            current = nextNode;
            isFirst = false;
        }
        
        // 随机选择一个可行位置
        if (!feasiblePositions.empty()) {
            int randomIndex = rand() % feasiblePositions.size();
            insertNodeAfter(solution, node, feasiblePositions[randomIndex]);
        }
    }
    
    int routeIndex = 0;
    solution->updateRouteInfor(routeIndex);
}

// 5. 簇内替换修复+轮盘赌
void SA_Enhanced::clusterSwapRepair(Individual* solution, std::vector<int>& removedNodes) {
    // 按优先级约束排序
    std::vector<std::pair<int, int>> nodeWithPriority;
    for (int node : removedNodes) {
        int precedenceCount = 0;
        for (int otherNode : removedNodes) {
            if (data->precedenceConstraints[node][otherNode] == -1) {
                precedenceCount++;
            }
        }
        nodeWithPriority.push_back({precedenceCount, node});
    }
    std::sort(nodeWithPriority.begin(), nodeWithPriority.end());
    
    for (auto& pair : nodeWithPriority) {
        int removedNode = pair.second;
        int cluster = data->nodeGroup[removedNode];
        
        // 第一步：快速收集所有(节点, 位置, 成本)候选，不检查约束
        std::vector<std::tuple<int, Node*, double>> allCandidates;
        
        for (int candidateNode : data->groupNodes[cluster]) {
            Node* current = &solution->client[solution->start[0]];
            bool isFirst = true;
            
            while (current->cour != solution->start[0] || isFirst) {
                Node* nextNode = current->next;
                double cost = data->D[current->cour][candidateNode] + data->D[candidateNode][nextNode->cour] 
                            - data->D[current->cour][nextNode->cour];
                allCandidates.push_back(std::make_tuple(candidateNode, current, cost));
                current = nextNode;
                isFirst = false;
            }
        }
        
        // 第二步：按成本排序，只对 top 候选检查约束
        std::sort(allCandidates.begin(), allCandidates.end(), 
            [](const std::tuple<int, Node*, double>& a, const std::tuple<int, Node*, double>& b) { 
                return std::get<2>(a) < std::get<2>(b); 
            });
        
        std::vector<std::tuple<int, Node*, double>> feasibleCandidates;
        int maxCheck = std::min((int)allCandidates.size(), 20);  // 最多检查20个候选
        
        for (int i = 0; i < maxCheck; i++) {
            int candidateNode = std::get<0>(allCandidates[i]);
            Node* pos = std::get<1>(allCandidates[i]);
            double cost = std::get<2>(allCandidates[i]);
            
            insertNodeAfter(solution, candidateNode, pos);
            bool satisfies = checkNodeConstraints(solution, candidateNode);
            removeNodeFromList(solution, candidateNode);
            
            if (satisfies) {
                feasibleCandidates.push_back(allCandidates[i]);
            }
        }
        
        Node* selectedPos = NULL;
        int selectedNode = -1;
        
        if (!feasibleCandidates.empty()) {
            // 轮盘赌选择：成本越小，权重越大
            double maxCost = std::get<2>(feasibleCandidates.back());
            
            std::vector<double> weights;
            double totalWeight = 0.0;
            for (auto& c : feasibleCandidates) {
                double weight = maxCost - std::get<2>(c) + 1.0;
                weights.push_back(weight);
                totalWeight += weight;
            }
            
            double randValue = (double)rand() / RAND_MAX * totalWeight;
            double cumulative = 0.0;
            for (size_t i = 0; i < feasibleCandidates.size(); i++) {
                cumulative += weights[i];
                if (randValue <= cumulative) {
                    selectedNode = std::get<0>(feasibleCandidates[i]);
                    selectedPos = std::get<1>(feasibleCandidates[i]);
                    break;
                }
            }
        }
        
        if (selectedPos != NULL && selectedNode >= 0) {
            insertNodeAfter(solution, selectedNode, selectedPos);
        }
    }
    
    int routeIndex = 0;
    solution->updateRouteInfor(routeIndex);
}

void SA_Enhanced::resetWeights() {// 远期“硬重置”权重（未调用）
    // 周期性重置权重（每隔一段时间）
    segmentCount++;
    if (segmentCount % 10 == 0) {  // 每10个更新周期重置一次50*10
        initializeWeights();
    }
}

void SA_Enhanced::periodicRestart(double currentBestDis, int restartInterval, int episodeLength) {//定期重启（未调用）
    // 定期完全重启
    
    // 1. 重新计算初始温度
    double logAcceptProb = std::log(acceptanceProbability);
    initialTemperature = -temperatureParameter * currentBestDis / logAcceptProb;
    temperature = initialTemperature;
    
    // 2. 重新计算冷却率
    // cool_rate = pow((last_temperature/Initial_temperature), 1/(re_start * episod))
    double totalSteps = (double)(restartInterval * episodeLength);
    coolingRate = std::pow(lastTemperature / initialTemperature, 1.0 / totalSteps);
    
    // 3. 重置所有破坏和修复算子权重为1
    for (int i = 0; i < NUM_DESTROY_OPERATORS; i++) {
        destroyWeights[i] = 1.0;
        destroyScores[i] = 0.0;
        destroyUsage[i] = 0;
    }
    for (int i = 0; i < NUM_REPAIR_OPERATORS; i++) {
        repairWeights[i] = 1.0;
        repairScores[i] = 0.0;
        repairUsage[i] = 0;
    }
    
    // 4. 更新累积概率
    updateDestroyCumulativeProb();
    updateRepairCumulativeProb();
    
    std::cout << "Periodic restart: T=" << temperature << ", cooling_rate=" << coolingRate << std::endl;
}
