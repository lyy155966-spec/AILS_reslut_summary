/*
 */
#ifndef SA_H_
#define SA_H_
#include "read_data.h"
#include "Individual.h"
#include "LS.h"
class SA {
public:
	SA(read_data * data, LS * ls);
	virtual ~SA();
	void sa_function(Individual *s);
	void distoryAndRepair(Individual *s);
	LS * ls;
	Individual *global;
	Individual *loc_best;
	double initial_solution_fit;
	double Initial_temperature;
	int current_remove;
	int current_repair;
private:
	void update_weight();
	void simulate_anneling();

	read_data *data;
	Individual *s;
	bool usingMAB = 0;
	bool regular = 1;
	bool random = 0;


	int segment = 0;
	double gamama = 0.1;
	int delta_global_best = 10;
	int delta_improve = 5;
	int delta_accept = 3;

	double last_temperature=0.0001;
	double wwww = 0.35;// parameters for SA
	double p_accept = 0.7;
	//
	double activity_threshold = 1.01;
	double gama_accept_prob_greedy_heuristic = 0.01;
	//

	double *cum_prob_remove;
	double *cum_prob_repair;
	//variables for weight
	int n_remove = 5;
	int n_repair=3;
	double *weight_remove;
	double *score_remove;
	double *weight_repair;
	double *score_repair;
	int *num_remove;
	int *num_repair_used;
	// general variables
	int numV;
	int v_num;
	int perturbLength;
	int * cityRank;
	std::vector<int>listRemove;
	//
	void selectAndApplyDestoryOperator();
	void randomRemove();
	void shawRemoval();
	void crossRemove();
	void worstRemove();
	void historialInformationRemove();
	std::vector<std::pair<double,Node*>>worst_seq;
	std::vector<Route*> emptyRoute;
	std::vector<std::pair<int, Node*>>nearby_seq;
	std::vector<int>activity_score;
	std::vector<int>nodess;

	void selectAndApplyRepairOperator();

	void greedyInsert();
	void greedyInsertBlink();
	void regretInsert();
	void insertNode(Node *U, Node *V);
};

#endif /* SA_H_ */
