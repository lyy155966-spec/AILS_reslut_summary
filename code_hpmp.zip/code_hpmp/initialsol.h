#ifndef INITIALSOL_H_
#define INITIALSOL_H_
#include "read_data.h"
#include "Individual.h"
class initial_sol {
public:
	initial_sol(read_data * data);
	virtual ~initial_sol();
	void initial_solution(Individual *s);
private:
	Individual * s;
	read_data * data;
	int num_v;
	int num_p;
	std::vector< int >squVertices;// to randomize the order of all vertices
	int *usedVertices;

	//methods
	void greedyConstruct();
	void greedyConstructGTSP();  // Original GTSP method
	
	// Helper functions for v2
	bool checkNodeConstraintsForInsertion(int node, const std::vector<int>& tour);
	double calculateInsertionCost(const std::vector<int>& tour, int pos, int node);
	bool canSelectCluster(int cluster, const std::vector<int>& currentTour);


};
#endif /* INITIALSOL_H_ */
