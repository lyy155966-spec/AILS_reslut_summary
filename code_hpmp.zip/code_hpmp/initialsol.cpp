#include "basic.h"
#include "initialsol.h"
initial_sol::initial_sol(read_data * data) {
	this->data=data;
	this->num_v=data->num_v;
	this->num_p=data->num_p;
	for (int i=0;i<num_v;i++)
		squVertices.push_back(i);
	usedVertices=new int [num_v];
}

initial_sol::~initial_sol() {
	delete [] usedVertices;
}
//（TSP未被调用）
void initial_sol::greedyConstruct(){
	for (int i=0;i<data->num_v;i++){
		s->client[i].pre=NULL;
		s->client[i].next=NULL;
		s->client[i].route=NULL;
		s->client[i].cour=i;
	}
	//
	std::random_shuffle(squVertices.begin(), squVertices.end());
	for (int i=0;i<num_v;i++)usedVertices[i]=0;
	/*first step*/
	for (int i=0;i<num_p;i++){// using num_p vertices to initialize num_p tours.
		s->start[i]=squVertices[i];
		s->client[squVertices[i]].route=&s->route[i];
		s->route[i].start=squVertices[i];
		usedVertices[squVertices[i]]=1;
	}
	/*second step*/// inserting a vertex into each tour
	int delta;int canVertex;
	Node *p=NULL;
	for (int i=0;i<num_p;i++){
		delta=Max;p=&s->client[s->start[i]];
		for (int j=0;j<(int)data->edge_node[p->cour].size();j++){
			if (usedVertices[data->edge_node[p->cour][j]]==0 && data->D[p->cour][data->edge_node[p->cour][j]] < delta){
				delta=data->D[p->cour][data->edge_node[p->cour][j]];
				canVertex=data->edge_node[p->cour][j];
			}
		}
		if (delta == Max){
			for (int j=0;j<num_v;j++)
				if (usedVertices[j] == 0)
					canVertex = j;
		}
		p->next=&s->client[canVertex];
		s->client[canVertex].pre=p;
		s->client[canVertex].next=p;
		p->pre=&s->client[canVertex];
		s->client[canVertex].route=p->route;
		usedVertices[canVertex]=1;
	}
	for (int i=0;i<num_p;i++){
		delta=Max;p=&s->client[s->start[i]];
		for (int j=0;j<(int)data->edge_node[p->cour].size();j++){
			if (usedVertices[data->edge_node[p->cour][j]]==0 && ((data->D[p->cour][data->edge_node[p->cour][j]] + data->D[data->edge_node[p->cour][j]][p->next->cour] - data->D[p->cour][p->next->cour]) < delta)){
				delta = data->D[p->cour][data->edge_node[p->cour][j]] + data->D[data->edge_node[p->cour][j]][p->next->cour] - data->D[p->cour][p->next->cour];
				canVertex=data->edge_node[p->cour][j];
			}
		}
		p=p->next;
		for (int j=0;j<(int)data->edge_node[p->cour].size();j++){
			if (usedVertices[data->edge_node[p->cour][j]]==0 && ((data->D[p->pre->cour][data->edge_node[p->cour][j]] + data->D[data->edge_node[p->cour][j]][p->cour] - data->D[p->cour][p->pre->cour]) < delta)){
				delta = data->D[p->cour][data->edge_node[p->cour][j]] + data->D[data->edge_node[p->cour][j]][p->next->cour] - data->D[p->cour][p->next->cour];
				canVertex=data->edge_node[p->cour][j];
			}
		}
		if (delta == Max){
			for (int j=0;j<num_v;j++)
				if (usedVertices[j] == 0)
					canVertex = j;
		}
		p=&s->client[s->start[i]];
		Node *pAfter=p->next;
		p->next=&s->client[canVertex];
		s->client[canVertex].pre=p;
		s->client[canVertex].next=pAfter;
		pAfter->pre = &s->client[canVertex];
		s->client[canVertex].route=p->route;
		usedVertices[canVertex]=1;
	}
	//inserting remaining vertices
	double min_delta;int after;int targetVertex;
	bool isFirst;
	while(1){
		min_delta=Max;
		for (int i=0;i<num_p;i++){
			p=&s->client[s->start[i]];
			isFirst=true;
			while(p->cour != s->start[i] || isFirst){
				for (int j=0;j<(int)data->edge_node[p->cour].size();j++){
					if (usedVertices[data->edge_node[p->cour][j]] != 0)continue;
					delta=data->D[p->cour][data->edge_node[p->cour][j]] + data->D[data->edge_node[p->cour][j]][p->next->cour] - data->D[p->cour][p->next->cour];
					if (delta < min_delta){
						min_delta = delta;
						after = p->cour;
						targetVertex = data->edge_node[p->cour][j];
					}
				}
				isFirst=false;
				p=p->next;
			}
		}
		if (min_delta == Max)break;
		p=&s->client[after];
		Node *pAfter=p->next;
		p->next=&s->client[targetVertex];
		s->client[targetVertex].pre=p;
		s->client[targetVertex].next=pAfter;
		pAfter->pre=&s->client[targetVertex];
		s->client[targetVertex].route=p->route;
		usedVertices[targetVertex]=1;
	}
	//check the feasibility;
	for (int i=0;i<num_v;i++){
		if (usedVertices[i] == 0){
			min_delta = Max;
			for (int j=0;j<(int)data->edge_node[i].size();j++){
				if (usedVertices[data->edge_node[i][j]] == 1){
					p=&s->client[data->edge_node[i][j]];
					delta = data->D[p->cour][i]+data->D[i][p->next->cour] - data->D[p->cour][p->next->cour];
					if (min_delta > delta){
						after=p->cour;
						targetVertex=i;
						min_delta = delta;
					}
				}
			}
			if (min_delta==Max)continue;
			p=&s->client[after];
			Node *pAfter=p->next;
			p->next=&s->client[targetVertex];
			s->client[targetVertex].pre=p;
			s->client[targetVertex].next=pAfter;
			pAfter->pre=&s->client[targetVertex];
			s->client[targetVertex].route=p->route;
			usedVertices[targetVertex]=1;
		}
	}
	//if there are still non-inserted vertices, all of them are inserted into the first route.
	for (int i=0;i<num_v;i++){
		if (usedVertices[i] == 0){
			p = &s->client[s->start[0]];
			Node * nextP = p->next;
			p->next = &s->client[i];
			s->client[i].pre=p;
			nextP->pre = &s->client[i];
			s->client[i].next=nextP;
			s->client[i].route=p->route;
		}
	}
	for (int i=0;i<num_p;i++)
		s->updateRouteInfor(i);
}


void initial_sol::initial_solution(Individual *s){
	this->s=s;
	
	// GTSP
	if (data->isGTSP){
		std::cout << "Generating GTSP initial solution" << std::endl;
		
		greedyConstructGTSP();  // 贪婪插入
		
		s->evaluationDis();
		s->outputSolution();
		s->isRightGTSP();  // GTSP
	} else {
		greedyConstruct();
		s->evaluationDis();
//		s->outputSolution();
		s->isRight();
	}
}

bool initial_sol::canSelectCluster(int cluster, const std::vector<int>& currentTour) {
    // 检查簇中是否有任何节点可以被插入（考虑优先级约束）
    
    for (int node : data->groupNodes[cluster]) {
        bool nodeFeasible = true;
        
        // 检查：是否有已在路径中的节点必须在当前节点之后
        for (int tourNode : currentTour) {
            // precedenceConstraints[tourNode][node] == -1 表示 tourNode 必须在 node 之后
            // 但 tourNode 已经在路径中，所以 node 不能被插入
            if (data->precedenceConstraints[tourNode][node] == -1) {
                nodeFeasible = false;
                break;
            }
        }
        
        if (nodeFeasible) {
            return true;  // 簇中至少有一个节点可以被插入
        }
    }
    
    return false;  // 簇中所有节点都不能被插入
}

// 检查节点插入后是否满足优先级约束
bool initial_sol::checkNodeConstraintsForInsertion(int node, const std::vector<int>& tour) {
    // 创建位置映射
    std::vector<int> position(data->num_v, -1);
    for (size_t i = 0; i < tour.size(); i++) {
        position[tour[i]] = i;
    }
    
    int nodePos = position[node];
    if (nodePos == -1) return true;  // 节点不在路径中
    
    // 约束1: 检查 node 必须在哪些节点之后
    for (int i = 0; i < data->num_v; i++) {
        if (data->precedenceConstraints[node][i] == -1) {
            // node 必须在节点i之后
            if (position[i] != -1 && nodePos <= position[i]) {
                return false;  // 违反约束：node 在 i 之前或同位置
            }
        }
    }
    
    // 约束2: 检查哪些节点必须在 node 之后
    for (int i = 0; i < data->num_v; i++) {
        if (data->precedenceConstraints[i][node] == -1) {
            // 节点i 必须在 node 之后
            if (position[i] != -1 && position[i] <= nodePos) {
                return false;  // 违反约束：i 在 node 之前或同位置
            }
        }
    }
    
    return true;  // 所有约束满足
}

// 计算插入成本
double initial_sol::calculateInsertionCost(const std::vector<int>& tour, int pos, int node) {
    int prev = tour[pos];
    int next = tour[(pos + 1) % tour.size()];
    
    // 插入成本 = 新增的两条边 - 删除的一条边
    double cost = data->D[prev][node] + data->D[node][next] - data->D[prev][next];
    return cost;
}

// 贪婪插入构造
void initial_sol::greedyConstructGTSP() {
    // 阶段1: 初始化
    for (int i = 0; i < data->num_v; i++) {
        s->client[i].pre = NULL;
        s->client[i].next = NULL;
        s->client[i].route = NULL;
        s->client[i].cour = i;
    }
    
    // 从起始簇开始
    int startCluster = data->startGroup;
    int startNode = 0;  // 假设节点0在起始簇
    
    // 验证节点0确实在起始簇中
    bool node0InStartCluster = false;
    for (int node : data->groupNodes[startCluster]) {
        if (node == 0) {
            node0InStartCluster = true;
            break;
        }
    }
    
    if (!node0InStartCluster) {
        startNode = data->groupNodes[startCluster][0];
    }
    
    std::vector<int> currentTour = {startNode};//动态数组，存储当前已构建的路径
    std::vector<bool> clusterUsed(data->num_groups + 1, false);//标记哪些簇已经被使用
    clusterUsed[startCluster] = true;
    
    // 渐进式贪婪插入
    int iteration = 0;
    
    while ((int)currentTour.size() < data->num_groups) {
        iteration++;
        
        int bestNode = -1;
        int bestPos = -1;
        int bestCluster = -1;
        double bestCost = Max;
        
        // 先计算到每个簇的平均距离，只考虑最近的top-K个簇
        std::vector<std::pair<double, int>> clusterDistances;
        
        for (int cluster = 1; cluster <= data->num_groups; cluster++) {
            if (clusterUsed[cluster]) continue;
            
            // 快速检查：簇是否可以被选择，优先级约束
            if (!canSelectCluster(cluster, currentTour)) continue;
            
            // 计算到簇的平均距离
            double totalDist = 0;
            int count = 0;
            for (int node : data->groupNodes[cluster]) {
                for (int tourNode : currentTour) {
                    totalDist += data->D[tourNode][node];
                    count++;
                }
            }
            double avgDist = (count > 0) ? (totalDist / count) : Max;
            clusterDistances.push_back({avgDist, cluster});
        }
        
        // 处理没有可行簇的情况
        if (clusterDistances.empty()) {
            // 强制尝试所有未使用的簇（忽略优先级约束）
            for (int cluster = 1; cluster <= data->num_groups; cluster++) {
                if (clusterUsed[cluster]) continue;
                
                double totalDist = 0;
                int count = 0;
                for (int node : data->groupNodes[cluster]) {
                    for (int tourNode : currentTour) {
                        totalDist += data->D[tourNode][node];
                        count++;
                    }
                }
                double avgDist = (count > 0) ? (totalDist / count) : Max;
                clusterDistances.push_back({avgDist, cluster});
            }
            
            if (clusterDistances.empty()) {
                break;
            }
        }
        
        // 排序并考虑最近的10个簇
        std::sort(clusterDistances.begin(), clusterDistances.end());
        int topK = std::min(10, (int)clusterDistances.size());
        
        // 添加随机性：打乱top-K簇的顺序
        if (topK > 1) {
            std::random_shuffle(clusterDistances.begin(), clusterDistances.begin() + topK);
        }
        
        // 遍历top-K个最近的簇
        for (int k = 0; k < topK; k++) {
            int cluster = clusterDistances[k].second;
            
            // 遍历簇中的所有节点
            for (int node : data->groupNodes[cluster]) {
                // 检查同簇约束：确保当前路径中没有同簇的其他节点
                bool sameClusterConflict = false;
                for (int tourNode : currentTour) {
                    if (data->sameCluster[node][tourNode] == 1) {
                        sameClusterConflict = true;
                        break;
                    }
                }
                if (sameClusterConflict) continue;
                
                // 遍历所有可能的插入位置
                for (int pos = 0; pos < (int)currentTour.size(); pos++) {
                    // 创建临时路径测试插入
                    std::vector<int> tempTour;
                    for (int i = 0; i <= (int)currentTour.size(); i++) {
                        if (i == pos + 1) {
                            tempTour.push_back(node);
                        }
                        if (i < (int)currentTour.size()) {
                            tempTour.push_back(currentTour[i]);
                        }
                    }
                    
                    // 检查优先级约束
                    if (!checkNodeConstraintsForInsertion(node, tempTour)) continue;
                    
                    // 计算插入成本
                    double cost = calculateInsertionCost(currentTour, pos, node);
                    
                    // 更新最佳选择
                    if (cost < bestCost) {
                        bestCost = cost;
                        bestNode = node;
                        bestPos = pos;
                        bestCluster = cluster;
                    }
                }
            }
        }
        
        // 如果top-K没找到，扩大搜索范围
        if (bestNode == -1 && topK < (int)clusterDistances.size()) {
            // 搜索所有候选簇
            for (int k = topK; k < (int)clusterDistances.size(); k++) {
                int cluster = clusterDistances[k].second;
                
                for (int node : data->groupNodes[cluster]) {
                    bool sameClusterConflict = false;
                    for (int tourNode : currentTour) {
                        if (data->sameCluster[node][tourNode] == 1) {
                            sameClusterConflict = true;
                            break;
                        }
                    }
                    if (sameClusterConflict) continue;
                    
                    for (int pos = 0; pos < (int)currentTour.size(); pos++) {
                        std::vector<int> tempTour;
                        for (int i = 0; i <= (int)currentTour.size(); i++) {
                            if (i == pos + 1) {
                                tempTour.push_back(node);
                            }
                            if (i < (int)currentTour.size()) {
                                tempTour.push_back(currentTour[i]);
                            }
                        }
                        
                        if (!checkNodeConstraintsForInsertion(node, tempTour)) continue;
                        
                        double cost = calculateInsertionCost(currentTour, pos, node);
                        
                        if (cost < bestCost) {
                            bestCost = cost;
                            bestNode = node;
                            bestPos = pos;
                            bestCluster = cluster;
                        }
                    }
                }
                
                if (bestNode != -1) break;  // 找到就停止
            }
        }
       
        
        // 执行插入
        std::vector<int> newTour;
        for (int i = 0; i <= (int)currentTour.size(); i++) {
            if (i == bestPos + 1) {
                newTour.push_back(bestNode);
            }
            if (i < (int)currentTour.size()) {
                newTour.push_back(currentTour[i]);
            }
        }
        
        currentTour = newTour;
        clusterUsed[bestCluster] = true;
    }
    
    // 构建环形链表
    if ((int)currentTour.size() < data->num_groups) {
        std::cout << "WARNING: Not all clusters visited! Missing " << (data->num_groups - currentTour.size()) << " clusters" << std::endl;
    }
    
    s->start[0] = currentTour[0];
    s->route[0].start = currentTour[0];
    s->route[0].cour = 0;// 路径编号为0
    
    for (int i = 0; i < (int)currentTour.size(); i++) {
        int current = currentTour[i];
        int next = currentTour[(i + 1) % currentTour.size()];
        
        s->client[current].next = &s->client[next];
        s->client[next].pre = &s->client[current];
        s->client[current].route = &s->route[0];
    }
    
    int routeIndex = 0;
    s->updateRouteInfor(routeIndex);
    
}