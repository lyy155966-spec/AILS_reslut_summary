#include "MyLS.h"
#include "basic.h"
#include <iostream>

// 构造函数：初始化数据指针和变量
MyLS::MyLS(read_data* data) {
    this->data = data;
    this->num_v = data->num_v;
    this->num_p = data->num_p;
    
}

// 析构函数
MyLS::~MyLS() {
}

// 初始化解：设置所有节点的whenLastTestedRI为-1，并清洗route指针
void MyLS::load_solution() {
    // 1. 重置所有节点的测试时间和route指针（清除脏数据）
    for (int i = 0; i < num_v; i++) {
        s->client[i].whenLastTestedRI = -1;
        s->client[i].route = NULL;  // 强制清除脏数据
    }

    // 2. 遍历实际路径，重新标记在途节点的route指针
    for (int r = 0; r < num_p; r++) {//只有一条路径，只走一遍
        Node* p = &s->client[s->start[r]];
        bool isFirst = true;
        
        while (p->cour != s->start[r] || isFirst) {
            p->route = &s->route[r];  // 标记该节点在路径0上
            p = p->next;
            isFirst = false;
        }
    }
}

// 设置nodeU相关的局部变量
bool MyLS::setLocalVariableRouteU() {
    if (!nodeU || !nodeU->next || !nodeU->pre) return false;
    
    nodeX = nodeU->next;                      // nodeU的下一个节点
    if (!nodeX->next) return false;
    
    nodeXNextIndex = nodeX->next->cour;       // nodeX的下一个节点的索引
    nodeUIndex = nodeU->cour;                 // nodeU的索引
    nodeUPrevIndex = nodeU->pre->cour;        // nodeU的前一个节点的索引
    nodeXIndex = nodeX->cour;                 // nodeX的索引
    return true;
}

// 设置nodeV相关的局部变量
bool MyLS::setLocalVariableRouteV() {
    if (!nodeV || !nodeV->next || !nodeV->pre) return false;
    
    nodeY = nodeV->next;                      // nodeV的下一个节点
    if (!nodeY->next) return false;
    
    nodeYNextIndex = nodeY->next->cour;       // nodeY的下一个节点的索引
    nodeVIndex = nodeV->cour;                 // nodeV的索引
    nodeVPrevIndex = nodeV->pre->cour;        // nodeV的前一个节点的索引
    nodeYIndex = nodeY->cour;                 // nodeY的索引
    return true;
}

// 更新路径信息：重新计算位置和累积距离
void MyLS::updateRouteData(int& r) {
    // 获取路径起点
    Node* p = &s->client[s->start[r]];
    
    // 初始化起点的位置和累积距离
    p->position = 0;
    p->cumulatedDis = 0;
    
    bool isFirst = true;
    
    // 遍历整个环形路径，更新每个节点的位置和累积距离
    while (p->cour != s->start[r] || isFirst) {
        p = p->next;  // 移动到下一个节点
        p->position = p->pre->position + 1;  // 位置 = 前一个节点位置 + 1
        p->cumulatedDis = data->D[p->pre->cour][p->cour] + p->pre->cumulatedDis;  // 累积距离 = 前一个节点累积距离 + 边距离
        isFirst = false;
    }
    
    // 更新路径总距离（包括最后一条边：最后节点回到起点）
    s->route[r].dis = p->cumulatedDis + data->D[p->cour][s->start[r]];
    // 更新路径节点数量
    s->route[r].nbClients = p->position + 1;
    // 更新路径最后修改时间
    s->route[r].whenLastModified = nbMoves;
}

// 增量式约束检查：只检查指定节点与路径上其他节点的约束关系
bool MyLS::checkNodeConstraintsIncremental(int node, const std::vector<int>& currentPath) {
    bool nodeFound = false;
    
    for (int otherNode : currentPath) {
        if (otherNode == node) {
            nodeFound = true;
            continue;
        }
        
        if (!nodeFound) {
            // otherNode 在 node 之前
            // 检查：如果 otherNode 必须在 node 之后 (precedenceConstraints[otherNode][node] == -1)，则违反
            if (data->precedenceConstraints[otherNode][node] == -1) return false;
        } else {
            // otherNode 在 node 之后
            // 检查：如果 node 必须在 otherNode 之后 (precedenceConstraints[node][otherNode] == -1)，则违反
            if (data->precedenceConstraints[node][otherNode] == -1) return false;
        }
    }
    
    return true;
    //     // 创建位置映射
    // std::vector<int> position(num_v, -1);
    // for (size_t i = 0; i < currentPath.size(); i++) {
    //     position[currentPath[i]] = i;
    // }
    
    // int nodePos = position[node];
    // if (nodePos == -1) return true;  // 节点不在路径中
    
    // // 检查：node必须在哪些节点之后
    // for (int j : data->mustAfter[node]) {
    //     if (position[j] != -1 && nodePos <= position[j]) {
    //         return false;  // node应该在j之后，但实际在j之前或同位置
    //     }
    // }
    
    // // 检查：哪些节点必须在node之后
    // for (int i : data->mustBefore[node]) {
    //     if (position[i] != -1 && position[i] <= nodePos) {
    //         return false;  // i应该在node之后，但实际在node之前或同位置
}

// 检查优先级约束：只检查反转区间内部的节点对
bool MyLS::checkPrecedenceConstraints(Node* segmentStart, Node* segmentEnd) {
    // 收集反转区间内的所有节点（反转前的顺序）
    std::vector<int> segmentNodes;
    Node* current = segmentStart;
    
    int loopCount = 0;
    int maxNodes = s->route[0].nbClients + 10;

    while (true) {
        segmentNodes.push_back(current->cour);
        if (current == segmentEnd) break;
        current = current->next;
        
        loopCount++;
        if (loopCount > maxNodes) {
             //std::cout << "Error: Infinite loop detected in checkPrecedenceConstraints" << std::endl;
             return false;
        }
    }
    
    // 检查反转后区间内的节点对是否满足约束
    for (size_t i = 0; i < segmentNodes.size(); i++) {
        for (size_t j = i + 1; j < segmentNodes.size(); j++) {
            // 反转前：segmentNodes[i] 在 segmentNodes[j] 之前
            // 反转后：segmentNodes[j] 在 segmentNodes[i] 之前
            
            int node_i = segmentNodes[i];
            int node_j = segmentNodes[j];
            
            // precedenceConstraints[A][B] == -1 表示：A必须在B之后
            // 反转后 node_j 在 node_i 之前
            // 如果 node_j 必须在 node_i 之后，则违反约束
            if (data->precedenceConstraints[node_j][node_i] == -1) {
                return false;
            }
        }
    }
    
    return true;
}

// 2-opt操作：尝试反转路径中的一段来改进解
bool MyLS::move_twoOpt() {
    // 检查nodeU的位置是否在nodeV之前（2-opt要求）
    if (nodeU->position > nodeV->position) return false;
    
    // 如果nodeU的下一个节点就是nodeV，不能执行2-opt（区间太小）
    if (nodeU->next == nodeV) return false;
    
    // 如果nodeX的下一个节点就是nodeV，区间太小，不能反转
    if (nodeX->next == nodeV) return false;
    
    // 检查反转区间[nodeX->next, nodeV]是否满足优先级约束（与实际反转的区间一致）
    if (!checkPrecedenceConstraints(nodeX, nodeV)) {//++++++++++++++++++if (!checkPrecedenceConstraints(nodeX->next, nodeV)) 
        return false;
    }
    
    // ===== 计算2-opt移动的增量成本（非对称矩阵）=====
    
    // 1. 计算反转前区间内的总距离
    double oldCost = 0.0;
    Node* current = nodeX;
    while (current != nodeV) {
        oldCost += data->D[current->cour][current->next->cour];  // 反转前的边
        current = current->next;
    }
    // 加上两条连接边：nodeU->nodeX 和 nodeV->nodeY
    oldCost += data->D[nodeUIndex][nodeXIndex];
    oldCost += data->D[nodeVIndex][nodeYIndex];
    
    // 2. 计算反转后区间内的总距离
    double newCost = 0.0;
    current = nodeX;
    while (current != nodeV) {
        newCost += data->D[current->next->cour][current->cour];  // 反转后的边（方向相反）
        current = current->next;
    }
    // 加上两条新的连接边：nodeU->nodeV 和 nodeX->nodeY
    newCost += data->D[nodeUIndex][nodeVIndex];
    newCost += data->D[nodeXIndex][nodeYIndex];
    
    // 3. 计算增量成本
    double deltaCost = newCost - oldCost;
    
    // 如果增量成本 >= 0，不改进，返回false
    if (deltaCost > -Min) return false;
    
    // ===== 执行2-opt反转操作（与LS中的move7完全一样）=====
    
    // 保存nodeX的下一个节点
    Node* nodeNum = nodeX->next;
    
    // 更新nodeX的指针
    nodeX->pre = nodeNum;
    nodeX->next = nodeY;
    
    // 反转区间[nodeX->next, nodeV]中的所有节点
    while (nodeNum != nodeV) {
        Node* temp = nodeNum->next;  // 保存下一个节点
        nodeNum->next = nodeNum->pre;  // 反转next指针
        nodeNum->pre = temp;           // 反转pre指针
        nodeNum = temp;  // 移动到下一个节点
    }
    
    // 更新nodeV的指针
    nodeV->next = nodeV->pre;
    nodeV->pre = nodeU;
    
    // 更新nodeU和nodeY的指针
    nodeU->next = nodeV;
    nodeY->pre = nodeX;
    
    // 增加移动计数器
    nbMoves++;
    // 标记搜索未完成（找到了改进）
    searchCompleted = false;
    
    // 更新路径信息（重新计算距离和位置）
    int routeIndex = 0;  // GTSP只有一条路径，索引为0
    updateRouteData(routeIndex);
    
    // 返回true表示找到改进
    return true;
}

// 将节点U从当前位置移除，插入到节点V之后
void MyLS::insertNode(Node* U, Node* V) {
    // GTSP中起点固定为0，不需要处理起点变化
    
    // 从原位置移除U
    U->pre->next = U->next;
    U->next->pre = U->pre;
    
    // 将U插入到V之后
    V->next->pre = U;
    U->pre = V;
    U->next = V->next;
    V->next = U;
}

// 检查relocate操作是否满足优先级约束（增量式）
bool MyLS::checkRelocate(Node* U, Node* insertAfter) {
    
    // 收集路径上的所有节点（移动后的顺序）
    std::vector<int> pathAfterMove;
    
    Node* current = &s->client[s->start[0]];
    bool isFirst = true;
    int loopCount = 0;
    int maxNodes = s->route[0].nbClients + 10;
    
    while ((current->cour != s->start[0] || isFirst) && loopCount < maxNodes) {
        loopCount++;
        
        if (!current || !current->next) {
            return false;  // 链表损坏
        }
        
        if (current == U) {
            // 跳过U（它会被移动到新位置）
            current = current->next;
            if (current->cour == s->start[0] && !isFirst) break;
            continue;
        }
        
        pathAfterMove.push_back(current->cour);
        
        // 如果当前节点是insertAfter，在它后面插入U
        if (current == insertAfter) {
            pathAfterMove.push_back(U->cour);
        }
        
        current = current->next;
        isFirst = false;
    }
    
    if (loopCount >= maxNodes) {
        return false;  // 检测到死循环
    }
    
    // 增量式检查：只检查移动的节点U的约束
    return checkNodeConstraintsIncremental(U->cour, pathAfterMove);
}

// Relocate操作：将nodeU重定位到nodeV之后
bool MyLS::move_relocate() {
    // 不能将节点移动到自己之后，或移动到自己的前一个节点之后
    if (nodeU == nodeV || nodeU->pre == nodeV) return false;
    // 不能移动起点
    if (nodeU->cour == s->start[0]) return false;
    // 检查优先级约束
    if (!checkRelocate(nodeU, nodeV)) {
        return false;
    }
    // 计算增量成本
    // 移除U的成本：删除 nodeU->pre -> nodeU -> nodeU->next
    double costRemove = data->D[nodeUPrevIndex][nodeXIndex] 
                      - data->D[nodeUPrevIndex][nodeUIndex] 
                      - data->D[nodeUIndex][nodeXIndex];
    
    // 插入U的成本：插入 nodeV -> nodeU -> nodeV->next
    double costInsert = data->D[nodeVIndex][nodeUIndex] 
                      + data->D[nodeUIndex][nodeYIndex] 
                      - data->D[nodeVIndex][nodeYIndex];
    
    double deltaCost = costRemove + costInsert;
    
    // 如果不改进，返回false
    if (deltaCost > -Min) return false;
    
    // 执行relocate操作
    insertNode(nodeU, nodeV);
    
    // 更新计数器和标志
    nbMoves++;
    searchCompleted = false;
    
    // 更新路径信息
    int routeIndex = 0;
    updateRouteData(routeIndex);
    
    return true;
}

// 交换两个节点的位置
void MyLS::swapNode(Node* U, Node* V) {
    // GTSP中起点固定为0，不需要处理起点变化
    
    // 保存U和V的前驱和后继
    Node* myVPred = V->pre;
    Node* myVSuiv = V->next;
    Node* myUPred = U->pre;
    Node* myUSuiv = U->next;
    
    // 更新前驱和后继的指针
    myUPred->next = V;
    myUSuiv->pre = V;
    myVPred->next = U;
    myVSuiv->pre = U;
    
    // 更新U和V的指针
    U->pre = myVPred;
    U->next = myVSuiv;
    V->pre = myUPred;
    V->next = myUSuiv;
}

// 检查swap操作是否满足优先级约束（增量式）
bool MyLS::checkSwap(Node* U, Node* V) {
    
    // 收集路径上的所有节点
    std::vector<int> pathAfterSwap;
    
    Node* current = &s->client[s->start[0]];
    bool isFirst = true;
    int loopCount = 0;
    int maxNodes = s->route[0].nbClients + 10;
    
    while ((current->cour != s->start[0] || isFirst) && loopCount < maxNodes) {
        loopCount++;
        
        if (!current || !current->next) {
            return false;  // 链表损坏
        }
        
        if (current == U) {
            // U的位置放V
            pathAfterSwap.push_back(V->cour);
        } else if (current == V) {
            // V的位置放U
            pathAfterSwap.push_back(U->cour);
        } else {
            pathAfterSwap.push_back(current->cour);
        }
        
        current = current->next;
        isFirst = false;
    }
    
    if (loopCount >= maxNodes) {
        return false;  // 检测到死循环
    }
    
    // 增量式检查：只检查U和V两个节点的约束
    return checkNodeConstraintsIncremental(U->cour, pathAfterSwap) && checkNodeConstraintsIncremental(V->cour, pathAfterSwap);
}

// Swap操作：交换nodeU和nodeV的位置
bool MyLS::move_swap() {
    // 不能交换相邻的节点（无意义或导致问题）
    if (nodeU->next == nodeV || nodeV->next == nodeU) return false;
    
    // 不能交换起点
    if (nodeU->cour == s->start[0] || nodeV->cour == s->start[0]) return false;
    
    // nodeU必须在nodeV之前（避免重复检查）
    if (nodeU->position > nodeV->position) return false;
    
    // 检查优先级约束
    if (!checkSwap(nodeU, nodeV)) {
        return false;
    }
    
    // 计算增量成本
    // U位置的成本变化：nodeU->pre -> nodeV -> nodeU->next
    double costU = data->D[nodeUPrevIndex][nodeVIndex] 
                 + data->D[nodeVIndex][nodeXIndex] 
                 - data->D[nodeUPrevIndex][nodeUIndex] 
                 - data->D[nodeUIndex][nodeXIndex];
    
    // V位置的成本变化：nodeV->pre -> nodeU -> nodeV->next
    double costV = data->D[nodeVPrevIndex][nodeUIndex] 
                 + data->D[nodeUIndex][nodeYIndex] 
                 - data->D[nodeVPrevIndex][nodeVIndex] 
                 - data->D[nodeVIndex][nodeYIndex];
    
    double deltaCost = costU + costV;
    
    // 如果不改进，返回false
    if (deltaCost > -Min) return false;
    
    // 执行swap操作
    swapNode(nodeU, nodeV);
    
    // 更新计数器和标志
    nbMoves++;
    searchCompleted = false;
    
    // 更新路径信息
    int routeIndex = 0;
    updateRouteData(routeIndex);
    
    return true;
}

// 检查节点替换是否满足优先级约束（增量式）
// 直接遍历链表构建替换后的路径，确保使用实时的路径顺序
bool MyLS::checkNodeReplacement(int newNode, Node* oldNode) {
    // 遍历链表构建替换后的路径
    std::vector<int> pathAfterReplacement;
    
    Node* current = &s->client[s->start[0]];
    bool isFirst = true;
    int loopCount = 0;
    int maxNodes = s->route[0].nbClients + 10;
    
    while ((current->cour != s->start[0] || isFirst) && loopCount < maxNodes) {
        loopCount++;
        
        if (!current || !current->next) {
            return false;  // 链表损坏
        }
        
        if (current == oldNode) {
            // 用新节点替换旧节点
            pathAfterReplacement.push_back(newNode);
        } else {
            pathAfterReplacement.push_back(current->cour);
        }
        
        current = current->next;
        isFirst = false;
    }
    
    if (loopCount >= maxNodes) {
        return false;  // 检测到死循环
    }
    
    // 增量式检查：只检查新节点的约束
    return checkNodeConstraintsIncremental(newNode, pathAfterReplacement);
}

// NodeReplacement操作：用nodeV同簇的其他节点替换nodeV
bool MyLS::move_nodeReplacement() {
    // nodeV必须在路径上
    if (nodeV->route == NULL) return false;
    
    // 不能替换起点
    if (nodeV->cour == s->start[0]) return false;
    
    int currentNode = nodeV->cour;
    int currentGroup = data->nodeGroup[currentNode];
    int prevIndex = nodeV->pre->cour;
    int nextIndex = nodeV->next->cour;
    
    // 遍历同簇的候选节点
    for (int candidateNode : data->groupNodes[currentGroup]) {
        if (candidateNode == currentNode) continue;
        

        if (s->client[candidateNode].route != NULL) {
             std::cout << "CRITICAL WARNING: Candidate " << candidateNode 
                       << " (Group " << data->nodeGroup[candidateNode] << ")"
                       << " found in Group " << currentGroup << " list, and it is ALREADY in route!" << std::endl;}

        // 计算替换成本
        double oldCost = data->D[prevIndex][currentNode] + data->D[currentNode][nextIndex];
        double newCost = data->D[prevIndex][candidateNode] + data->D[candidateNode][nextIndex];
        double deltaCost = newCost - oldCost;
        
        if (deltaCost < -Min) {
            // 检查优先级约束
            if (!checkNodeReplacement(candidateNode, nodeV)) {
                continue;
            }
            
            // 执行替换
            Node* newNode = &s->client[candidateNode];
            Node* nodePrev = nodeV->pre;
            Node* nodeNext = nodeV->next;
            
            nodePrev->next = newNode;
            nodeNext->pre = newNode;
            newNode->pre = nodePrev;
            newNode->next = nodeNext;
            newNode->route = nodeV->route;
            
            nodeV->pre = NULL;
            nodeV->next = NULL;
            nodeV->route = NULL;
            
            // 更新路由信息
            nbMoves++;
            searchCompleted = false;
            
            int routeIndex = 0;
            updateRouteData(routeIndex);
            return true;
        }
    }
    
    return false;
}

// 主循环：类似LS::srun()的结构
void MyLS::srun() {
    // 初始化移动计数器
    nbMoves = 0;
    
    // 收集路径上的所有节点（只遍历路径上的节点）
    orderNodes.clear();
    Node* current = &s->client[s->start[0]];
    bool isFirst = true;
    while (current->cour != s->start[0] || isFirst) {
        orderNodes.push_back(current->cour);
        current = current->next;
        isFirst = false;
    }
    
    // 随机打乱节点访问顺序
    random_shuffle(orderNodes.begin(), orderNodes.end());
    
    // 随机打乱部分节点的邻域顺序
    for (int i = 0; i < num_v; i++)
        if (rand() % data->alpha == 0)
            random_shuffle(data->edge_node[i].begin(), data->edge_node[i].end());
    
    // 初始化搜索完成标志
    searchCompleted = false;
    
    // 主循环：直到没有改进为止
    for (loopID = 0; !searchCompleted; loopID++) {
        searchCompleted = true;  // 假设本轮没有改进
        
        int testedPairs = 0;
        int improvedMoves = 0;
        
        // 遍历路径上的所有节点作为nodeU（按照orderNodes的顺序）
        int pathSize = (int)orderNodes.size();
        for (int posU = 0; posU < pathSize; posU++) {
            nodeU = &s->client[orderNodes[posU]];  // 获取当前nodeU
            
            // 跳过起点节点（从第二个节点开始）
            if (nodeU->cour == s->start[0]) continue;
            
            // 记录nodeU上次被测试的时间
            int lastTestRINodeU = nodeU->whenLastTestedRI;
            nodeU->whenLastTestedRI = nbMoves;
            
            // 遍历nodeU的邻域中的所有节点作为nodeV
            int neighborhoodSize = (int)data->edge_node[nodeU->cour].size();
            
            for (int posV = 0; posV < neighborhoodSize; posV++) {
                nodeV = &s->client[data->edge_node[nodeU->cour][posV]];  // 获取邻域中的节点
                
                // 检查nodeV是否在路径上
                if (nodeV->route == NULL) continue;
                
                // nodeV不能是起点（2-opt不应该反转包含起点的区间）
                if (nodeV->cour == s->start[0]) continue;
                
                // nodeV必须在nodeU后面至少2个位置
                if (nodeV->position <= nodeU->position + 1) continue;
                
                // 优化：只在第一轮或路径被修改后才测试
                if (loopID == 0 || s->route[0].whenLastModified > lastTestRINodeU) {
                    testedPairs++;
                    
                    // 设置局部变量（如果设置失败，跳过所有操作）
                    if (!setLocalVariableRouteU() || !setLocalVariableRouteV()) {
                        continue;
                    }
                    
                    // 尝试局部搜索操作（按优先级顺序：从简单到复杂）
                    if (move_nodeReplacement()) {
                        improvedMoves++;
                        continue;
                    }
                    if (move_relocate()) {
                        improvedMoves++;
                        continue;
                    }
                    if (move_swap()) {
                        improvedMoves++;
                        continue;
                    }
                    if (move_twoOpt()) {
                        improvedMoves++;
                        continue;
                    }
                }
            }
        }
        
        if (loopID >= 100) {
            std::cout << "Warning: Reached max iterations (100), forcing exit" << std::endl;
            break;
        }
    }
}

// 主函数：执行局部搜索
void MyLS::local_search_run(Individual* s) {
    // 保存当前解的指针
    this->s = s;
    
    // 初始化解
    load_solution();
    
    // s->isRightGTSP();

    // 执行主循环
    srun();
    
    // 重新计算总距离
    s->evaluationDis();
    
    // 验证解的完整性
    // s->isRightGTSP();
}
