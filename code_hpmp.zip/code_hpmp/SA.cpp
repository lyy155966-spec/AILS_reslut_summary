/*
 */
#include "SA.h"
SA::SA(read_data * data, LS *ls) {
	// TODO Auto-generated constructor stub

	this->data = data;
	this->ls = ls;
	this->numV = data->numV;
	this->v_num = data->v_num;
	cityRank = new int [numV];
	this->perturbLength = data->ratioPerturbLength*numV;
	//
	weight_remove = new double [n_remove];
	score_remove = new double [n_remove];
	weight_repair = new double [n_repair];
	score_repair = new double [n_repair];
	num_remove = new int [n_remove];
	num_repair_used = new int [n_repair];
	cum_prob_remove = new double [n_remove];
	cum_prob_repair = new double [n_repair];
	activity_score = std::vector<int>(numV);
}
SA::~SA() {
	delete [] cityRank;
	//
	delete [] weight_remove;
	delete [] score_remove;
	delete [] weight_repair;
	delete [] score_repair;
	delete [] num_remove;
	delete [] num_repair_used;
	delete [] cum_prob_remove;
	delete [] cum_prob_repair;
}
void SA::randomRemove(){
	int seed;
	nodess.clear();
	for (int i=1;i<numV;i++)	nodess.push_back(i);
	random_shuffle(nodess.begin(), nodess.end());
	listRemove.clear();
	while((int)listRemove.size() < perturbLength){//select more 1/3 cities and select randomly
		seed=rand()%(int)nodess.size();
		listRemove.push_back(nodess[seed]);
		s->client[nodess[seed]].isUsed = false;
		nodess.erase(nodess.begin()+seed);
	}
	Node *p = NULL;
	Node *pre = NULL, *next = NULL;
	for (int i=0;i<(int)listRemove.size();i++){
		p = &s->client[listRemove[i]];
		pre = p->pre;
		next = p->next;
		pre->next = next;
		next->pre = pre;
		p->pre = NULL;
		p->next = NULL;
		p->isUsed = false;
	}
	for (int i=0;i<v_num;i++){
		s->updateRouteInfor(s->route[i].cour, -1);
		if (s->route[i].nbClients == 1)
			emptyRoute.push_back(&s->route[i]);
	}
}
void SA::shawRemoval(){
	// the first step is to select customers
	int seed=rand()%(numV-1)+1;
	listRemove.clear();
	listRemove.push_back(seed); s->client[seed].isUsed = false;
	int iter;double y;int rank;
	while((int)listRemove.size() < perturbLength){//select more 1/3 cities and select randomly
		seed=rand()%(int)listRemove.size();
		iter=0;
		for (int i=0;i<numV;i++){
			if (data->nearCity[listRemove[seed]][i] > 0 && data->nearCity[listRemove[seed]][i] < numV && s->client[data->nearCity[listRemove[seed]][i]].isUsed){
				cityRank[iter]=data->nearCity[listRemove[seed]][i];
				iter++;
			}
		}
		y=double(rand()%10000/10000.0);
		rank=int(pow(y,data->determine_para)*iter);
		listRemove.push_back(cityRank[rank]);
		s->client[cityRank[rank]].isUsed = false;
	}
	//the second step is to remove customers
	Node *p = NULL;
	Node *pre = NULL, *next = NULL;
	for (int i=0;i<(int)listRemove.size();i++){
		p = &s->client[listRemove[i]];
		pre = p->pre;
		next = p->next;
		pre->next = next;
		next->pre = pre;
		p->pre = NULL;
		p->next = NULL;
		p->isUsed = false;
	}
	for (int i=0;i<v_num;i++){
		s->updateRouteInfor(s->route[i].cour, -1);
		if (s->route[i].nbClients == 1)
			emptyRoute.push_back(&s->route[i]);
	}
}
void SA::worstRemove(){
	double y;int rank; Node *p; double saving;
	listRemove.clear();
	worst_seq.clear();
	for (int i=1;i<numV;i++){
		p = &s->client[i];
		saving = data->D[p->pre->cour][p->cour] + data->D[p->cour][p->next->cour] - data->D[p->pre->cour][p->next->cour];
		worst_seq.push_back(make_pair(- saving, p));
	}
	sort(worst_seq.begin(), worst_seq.end());
	while((int)listRemove.size() < perturbLength){//select more 1/3 cities and select randomly
		y=double(rand()%10000/10000.0);
		rank=int(pow(y,data->determine_para)*(int)worst_seq.size());
		listRemove.push_back(worst_seq[rank].second->cour);
		worst_seq.erase(worst_seq.begin() + rank);
	}
	//the second step is to remove customers
	Node *pre = NULL, *next = NULL;
	for (int i=0;i<(int)listRemove.size();i++){
		p = &s->client[listRemove[i]];
		pre = p->pre;
		next = p->next;
		pre->next = next;
		next->pre = pre;
		p->pre = NULL;
		p->next = NULL;
		p->isUsed = false;
	}
	for (int i=0;i<v_num;i++){
		s->updateRouteInfor(s->route[i].cour, -1);
		if (s->route[i].nbClients == 1)
			emptyRoute.push_back(&s->route[i]);
	}
}
void SA::crossRemove(){//propose a new destroy operator, to construct the solution
	// the first step is to identify cross point or other
	listRemove.clear();
	nearby_seq.clear();
	int count;double y;int rank;
	for (int i=1;i<numV;i++){
		count = 0;
		for (int j=0; j<(int)data->edgeNode[i].size() / 2; j++){
			if (s->client[i].route != s->client[data->edgeNode[i][j]].route){
				count++;
			}
		}
		nearby_seq.push_back(make_pair(count, &s->client[i]));
	}
	sort(nearby_seq.begin(), nearby_seq.end());
	while((int)listRemove.size() < perturbLength){//select more 1/3 cities and select randomly
		y=double(rand()%10000/10000.0);
		rank=int(pow(y,data->determine_para)*(int)nearby_seq.size());
		listRemove.push_back(nearby_seq[rank].second->cour);
		nearby_seq.erase(nearby_seq.begin() + rank);
	}
	//the second step is to remove customers
	Node *pre = NULL, *next = NULL, *p;
	for (int i=0;i<(int)listRemove.size();i++){
		p = &s->client[listRemove[i]];
		pre = p->pre;
		next = p->next;
		pre->next = next;
		next->pre = pre;
		p->pre = NULL;
		p->next = NULL;
		p->isUsed = false;
	}
	for (int i=0;i<v_num;i++){
		s->updateRouteInfor(s->route[i].cour, -1);
		if (s->route[i].nbClients == 1)
			emptyRoute.push_back(&s->route[i]);
	}
}
void SA::historialInformationRemove(){
	std::vector<std::pair<int, Node *>>activ_nodes;
	for (int i=1;i<numV;i++){
		activ_nodes.push_back(make_pair( - activity_score[i], &s->client[i]));
	}
	sort(activ_nodes.begin(), activ_nodes.end());
	int length = (int)activ_nodes.size() - 1;
	for (int i=0;i<(int)activ_nodes.size();i++){/////there is no probability for no involved nodes;
		if (activ_nodes[i].first == 0){
			length = i;break;
		}
	}
	listRemove.clear();double y;int rank;
	while((int)listRemove.size() < perturbLength){//select more 1/3 cities and select randomly
		y=double(rand()%10000/10000.0);
		rank=int(pow(y,data->determine_para) * length);
		listRemove.push_back(activ_nodes[rank].second->cour);
		activ_nodes.erase(activ_nodes.begin() + rank);
		length = (int)activ_nodes.size();
	}
	//the second step is to remove customers
	Node *pre = NULL, *next = NULL, *p;
	for (int i=0;i<(int)listRemove.size();i++){
		p = &s->client[listRemove[i]];
		pre = p->pre;
		next = p->next;
		pre->next = next;
		next->pre = pre;
		p->pre = NULL;
		p->next = NULL;
		p->isUsed = false;
	}
	for (int i=0;i<v_num;i++){
		s->updateRouteInfor(s->route[i].cour, -1);
		if (s->route[i].nbClients == 1)
			emptyRoute.push_back(&s->route[i]);
	}
}
/*************************************************************************/
/*************************************************************************/
/*************************************************************************/
/*************************************************************************/
void SA::greedyInsert(){// for the shortest route
	//the third step is to add customers
	random_shuffle(listRemove.begin(), listRemove.end());// randomize all removed customers
	double delta, min_delta;
	Node *node, *nodeU, *pos;
//	auto min_length = s->rank_route.begin();
//	std::cout<<min_length->second->cour<<std::endl;
	while ((int)listRemove.size() != 0){
		auto min_length = s->rank_route.end();	min_length --;
		if (!emptyRoute.empty()){// once there are some empty routes.
			node = &s->client[listRemove[0]];
			pos = emptyRoute[0]->depot;
			insertNode(node,pos);
			listRemove.erase(listRemove.begin());
			emptyRoute.erase(emptyRoute.begin());
			s->updateRouteInfor(pos->route->cour,-1);
			continue;
		}
//		std::cout<<min_length->second->cour<<std::endl;
		min_delta = Max; //listRemove // insert the minimum route firstly
		pos = NULL;
		node = &s->client[listRemove[0]];
		for (int i=0;i<(int)data->edgeNode[node->cour].size();i++){
			if (s->client[data->edgeNode[node->cour][i]].route != min_length->second)continue;
			if (s->client[data->edgeNode[node->cour][i]].isUsed){
				nodeU = &s->client[data->edgeNode[node->cour][i]];
				if (nodeU->cour == 0)continue;
				delta = data->D[nodeU->cour][node->cour] + data->D[node->cour][nodeU->next->cour] - data->D[nodeU->cour][nodeU->next->cour];
				if (delta < min_delta){
					pos = nodeU;
					min_delta = delta;
				}
			}
		}
		// remedy strategy
		if (min_delta == Max){
			for (int i=0;i<(int)data->edgeNode[node->cour].size();i++){
				if (s->client[data->edgeNode[node->cour][i]].isUsed){
					nodeU = &s->client[data->edgeNode[node->cour][i]];
					if (nodeU->cour == 0)continue;
					delta = data->D[nodeU->cour][node->cour] + data->D[node->cour][nodeU->next->cour] - data->D[nodeU->cour][nodeU->next->cour];
					if (delta < min_delta){
						pos = nodeU;
						min_delta = delta;
					}
				}
			}
		}
		if (min_delta == Max){
			for (int i=0;i<(int)data->nearCity[node->cour].size();i++){
				if (s->client[data->nearCity[node->cour][i]].isUsed){
					nodeU = &s->client[data->nearCity[node->cour][i]];
					if (nodeU->cour == 0)continue;
					delta = data->D[nodeU->cour][node->cour] + data->D[node->cour][nodeU->next->cour] - data->D[nodeU->cour][nodeU->next->cour];
					if (delta < min_delta){
						pos = nodeU;
						min_delta = delta;
						break;// once obtain a feasible solution, then insert it.
					}
				}
			}
		}
		insertNode(node,pos);
		listRemove.erase(listRemove.begin());
		s->updateRouteInfor(pos->route->cour,-1);
	}
}
void SA::greedyInsertBlink(){// for the shortest route
	//the third step is to add customers
	random_shuffle(listRemove.begin(), listRemove.end());// randomize all removed customers
	double delta, min_delta;
	Node *node, *nodeU, *pos;
//	auto min_length = s->rank_route.begin();
//	std::cout<<min_length->second->cour<<std::endl;
	while ((int)listRemove.size() != 0){
		auto min_length = s->rank_route.end();	min_length --;
		if (!emptyRoute.empty()){// once there are some empty routes.
			node = &s->client[listRemove[0]];
			pos = emptyRoute[0]->depot;
			insertNode(node,pos);
			listRemove.erase(listRemove.begin());
			emptyRoute.erase(emptyRoute.begin());
			s->updateRouteInfor(pos->route->cour,-1);
			continue;
		}
//		std::cout<<min_length->second->cour<<std::endl;
		min_delta = Max; //listRemove // insert the minimum route firstly
		pos = NULL;
		node = &s->client[listRemove[0]];
		for (int i=0;i<(int)data->edgeNode[node->cour].size();i++){
			if (s->client[data->edgeNode[node->cour][i]].route != min_length->second)continue;
			if (s->client[data->edgeNode[node->cour][i]].isUsed){
				nodeU = &s->client[data->edgeNode[node->cour][i]];
				if (nodeU->cour == 0)continue;
				delta = data->D[nodeU->cour][node->cour] + data->D[node->cour][nodeU->next->cour] - data->D[nodeU->cour][nodeU->next->cour];
				if(rand()%10000/10000.0<(1 - gama_accept_prob_greedy_heuristic)){
					if (delta < min_delta){
						pos = nodeU;
						min_delta = delta;
					}
				}
			}
		}
		// remedy strategy
		if (min_delta == Max){
			for (int i=0;i<(int)data->edgeNode[node->cour].size();i++){
				if (s->client[data->edgeNode[node->cour][i]].isUsed){
					nodeU = &s->client[data->edgeNode[node->cour][i]];
					if (nodeU->cour == 0)continue;
					delta = data->D[nodeU->cour][node->cour] + data->D[node->cour][nodeU->next->cour] - data->D[nodeU->cour][nodeU->next->cour];
					if(rand()%10000/10000.0<(1 - gama_accept_prob_greedy_heuristic)){
						if (delta < min_delta){
							pos = nodeU;
							min_delta = delta;
						}
					}
				}
			}
		}
		if (min_delta == Max){
			for (int i=0;i<(int)data->nearCity[node->cour].size();i++){
				if (s->client[data->nearCity[node->cour][i]].isUsed){
					nodeU = &s->client[data->nearCity[node->cour][i]];
					if (nodeU->cour == 0)continue;
					delta = data->D[nodeU->cour][node->cour] + data->D[node->cour][nodeU->next->cour] - data->D[nodeU->cour][nodeU->next->cour];
					if (delta < min_delta){
						pos = nodeU;
						min_delta = delta;
						break;// once obtain a feasible solution, then insert it.
					}
				}
			}
		}
		insertNode(node,pos);
		listRemove.erase(listRemove.begin());
		s->updateRouteInfor(pos->route->cour,-1);
	}
}
void SA::regretInsert(){
	//the third step is to add customers
	random_shuffle(listRemove.begin(), listRemove.end());// randomize all removed customers
	std::set<std::pair<double, Node *>>regret_values;
	double delta;
	Node *node, *nodeU, *pos;
	while ((int)listRemove.size() != 0){
		regret_values.clear();
		auto min_route = s->rank_route.begin();
		if (!emptyRoute.empty()){// once there are some empty routes.
			node = &s->client[listRemove[0]];
			pos = emptyRoute[0]->depot;
			insertNode(node,pos);
			listRemove.erase(listRemove.begin());
			emptyRoute.erase(emptyRoute.begin());
			s->updateRouteInfor(pos->route->cour,-1);
			continue;
		}
		/*****************************************************************/
		pos = NULL;
		node = &s->client[listRemove[0]];
		for (int i=0;i<(int)data->edgeNode[node->cour].size();i++){
			if (s->client[data->edgeNode[node->cour][i]].route != min_route->second)continue;
			if (s->client[data->edgeNode[node->cour][i]].isUsed){
				nodeU = &s->client[data->edgeNode[node->cour][i]];
				if (nodeU->cour == 0)continue;
				delta = data->D[nodeU->cour][node->cour] + data->D[node->cour][nodeU->next->cour] - data->D[nodeU->cour][nodeU->next->cour];
				regret_values.insert(make_pair(delta, nodeU));
			}
		}
		// remedy strategy
		if (regret_values.empty()){
			for (int i=0;i<(int)data->edgeNode[node->cour].size();i++){
				if (s->client[data->edgeNode[node->cour][i]].isUsed){
					nodeU = &s->client[data->edgeNode[node->cour][i]];
					if (nodeU->cour == 0)continue;
					delta = data->D[nodeU->cour][node->cour] + data->D[node->cour][nodeU->next->cour] - data->D[nodeU->cour][nodeU->next->cour];
					regret_values.insert(make_pair(delta, nodeU));
				}
			}
		}
		if (regret_values.empty()){
			for (int i=0;i<(int)data->nearCity[node->cour].size();i++){
				if (s->client[data->nearCity[node->cour][i]].isUsed){
					nodeU = &s->client[data->nearCity[node->cour][i]];
					if (nodeU->cour == 0)continue;
					delta = data->D[nodeU->cour][node->cour] + data->D[node->cour][nodeU->next->cour] - data->D[nodeU->cour][nodeU->next->cour];
					if (delta < Max){
						pos = nodeU;
						break;// once obtain a feasible solution, then insert it.
					}
				}
			}
		}
		if (pos == NULL){
			auto it = regret_values.begin();
			if (regret_values.size() == 1)
				pos = it->second;
			else{
				it++;
				pos = it->second;
			}
		}
		insertNode(node,pos);
		listRemove.erase(listRemove.begin());
		s->updateRouteInfor(pos->route->cour,-1);
	}
}
void SA::insertNode(Node *U, Node *V){
	V->next->pre = U;
	U->next = V->next;
	V->next = U;
	U->pre = V;
	U->route = V->route;
	U->isUsed = true;
}
/***********Selecting destory and repair operators to perturb the solution********************/
void SA::selectAndApplyDestoryOperator(){

	int which_operator;
	if (regular){
		double prob=rand()%10000/10000.0;
		for (int i=0;i<n_remove;i++){
			if (i==0 &&prob<=cum_prob_remove[0]){
				which_operator=0;
				break;
			}
			if (prob>cum_prob_remove[i-1] && prob<=cum_prob_remove[i]){
				which_operator=i;
				break;
			}
		}
	}
	else if(usingMAB){
		double prob=rand()%10000/10000.0;
		if (prob < data->Epsilon){
			 which_operator = std::distance(weight_remove, std::max_element(weight_remove, weight_remove + n_remove));
		}
		else{
			 which_operator = rand() % (n_remove);
		}
	}
	else if (random){
		which_operator = rand() % (n_remove);
	}

	switch (which_operator){
		case 0:{
			shawRemoval();
			current_remove=0;
			num_remove[0]++;
			break;
		}
		case 1:{
			randomRemove();
	//		listRemove.clear();		ls->cross_exchange_tabu(s);
			current_remove=1;
			num_remove[1]++;
			break;
		}
		case 2:{
			crossRemove();
			current_remove=2;
			num_remove[2]++;
			break;
		}
		case 3:{
			worstRemove();
			current_remove=3;
			num_remove[3]++;
			break;
		}
		case 4:{
			historialInformationRemove();
			current_remove=4;
			num_remove[4]++;
			break;
		}
	}
}
void SA::selectAndApplyRepairOperator(){
	int which_operator;
	if (regular){
		double prob=rand()%10000/10000.0;
		for (int i=0;i<n_repair;i++){
			if (i==0 && prob<=cum_prob_repair[0]){
				which_operator=0;
				break;
			}
			if (prob>cum_prob_repair[i-1] && prob<=cum_prob_repair[i]){
				which_operator=i;
				break;
			}
		}
	}
	else if (usingMAB){
		double prob=rand()%10000/10000.0;
		if (prob < data->Epsilon){
			 which_operator = std::distance(weight_repair, std::max_element(weight_repair, weight_repair + n_repair));
		}
		else{
			 which_operator = rand() % (n_repair);
		}
	}
	else if (random){
		which_operator = rand() % (n_repair);
	}
	switch (which_operator){
		case 0:{
			greedyInsert();
			current_repair=0;
			num_repair_used[0]++;
			break;
		}
		case 1:{
			greedyInsertBlink();
			current_repair=1;
			num_repair_used[1]++;
			break;
		}
		case 2:{
			regretInsert();
			current_repair=2;
			num_repair_used[2]++;
			break;
		}
	}
}
void SA::update_weight(){
	double sum;int i;
	if (segment==0 || segment % data->re_start==0){
		for (int i=0;i<numV;i++)activity_score[i] = 0;// use to collect historical information

		for (i=0;i<n_remove;i++){weight_remove[i]=1;num_remove[i]=0; score_remove[i]=0;}
		for (i=0;i<n_repair;i++){weight_repair[i]=1;num_repair_used[i]=0; score_repair[i]=0;}
		//calculate the inital temperature
		double xx = std::log(p_accept);
		Initial_temperature=-wwww*initial_solution_fit/xx;
	//	last_temperature=1;
		double cccc=1.0/(data->re_start * data->episod);
		data->cool_rate=pow((last_temperature/Initial_temperature),cccc);
		sum=0;
		for (i=0;i<n_remove;i++)sum+=weight_remove[i];
		for (i=0;i<n_remove;i++){
			if (i==0)cum_prob_remove[i]=weight_remove[i]/sum;
			else cum_prob_remove[i]=cum_prob_remove[i-1]+weight_remove[i]/sum;
		}
		sum=0;
		for (i=0;i<n_repair;i++)sum+=weight_repair[i];
		for (i=0;i<n_repair;i++){
			if (i==0)cum_prob_repair[i]=weight_repair[i]/sum;
			else cum_prob_repair[i]=cum_prob_repair[i-1]+weight_repair[i]/sum;
		}
	}
	else{
		for (int i=0;i<numV;i++)activity_score[i] = 0;// use to collect historical information
		for (i=0;i<n_remove;i++){
			if (num_remove[i]!=0)
				weight_remove[i]=weight_remove[i]*(1-gamama)+gamama*(score_remove[i]/double(num_remove[i]));
			num_remove[i]=0;
			score_remove[i]=0;
		}
		sum=0;
		for ( i=0;i<n_remove;i++)sum+=weight_remove[i];
		for ( i=0;i<n_remove;i++){
			if (i==0)cum_prob_remove[i]=weight_remove[i]/sum;
			else cum_prob_remove[i]=cum_prob_remove[i-1]+weight_remove[i]/sum;
		}
		//
		for ( i=0;i<n_repair;i++){
			if (num_repair_used[i]!=0)
				weight_repair[i]=weight_repair[i]*(1-gamama)+gamama*(score_repair[i]/double(num_repair_used[i]));
			score_repair[i]=0;
			num_repair_used[i]=0;
		}
		sum=0;
		for ( i=0;i<n_repair;i++)sum+=weight_repair[i];
		for ( i=0;i<n_repair;i++){
			if (i==0)cum_prob_repair[i]=weight_repair[i]/sum;
			else cum_prob_repair[i]=cum_prob_repair[i-1]+weight_repair[i]/sum;
		}
	}
}
void SA::simulate_anneling(){
	//update the activity score
	if (s->max_dis * activity_threshold < loc_best->max_dis){// satisfy the condition
		for (int i=1;i<numV;i++)
			activity_score[i] = activity_score[i] + ls->activity_nodes[i];
	}
	/****************************************/
	Initial_temperature = Initial_temperature*data->cool_rate;
	if (s->max_dis+1.0e-7 < global->max_dis){// find a new global best solution, then updating global and local best solutions
		// once the best solution is updated, then the post optimization is triggerred.
		if (data->iteration > data->threshold_using_eax)
			ls->post_optimization(s);
		/////////////////////////////////////
		s->copySolution2other(global);
		s->copySolution2other(loc_best);
		score_remove[current_remove] += delta_global_best;
		score_repair[current_repair] += delta_global_best;
		return;
	}
	if (s->max_dis+1.0e-7<loc_best->max_dis ){
		s->copySolution2other(loc_best);
		score_remove[current_remove]+=delta_improve;
		score_repair[current_repair]+=delta_improve;
		return;
	}
	if (s->max_dis-1.0e-7 > loc_best->max_dis){
		double prob=rand()%10000/10000.0;
		double prob_accept=exp((loc_best->max_dis - s->max_dis)/Initial_temperature);
		if (prob<prob_accept){
			s->copySolution2other(loc_best);
			score_remove[current_remove]+=delta_accept;/////////////////////////////////////////////////////////////////
			score_repair[current_repair]+=delta_accept;//////////////////////////////////////////////////////////////////////
		}
		else
			loc_best->copySolution2other(s);
		return;
	}
}
void SA::distoryAndRepair(Individual *s){
	this->s = s;
	emptyRoute.clear();
	if (0){
		shawRemoval();
		greedyInsert();
	}
	else{//using multiple operators
		selectAndApplyDestoryOperator();
		selectAndApplyRepairOperator();
	}
	s->evaluationDis();
	s->isRight();
}
void SA::sa_function(Individual *s){
	if (data->iteration%data->episod==0){
		update_weight();
		segment++;
	}
	if (data->iteration != 0){
		s->isRight();
		simulate_anneling();
	}
}
