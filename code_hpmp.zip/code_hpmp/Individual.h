#ifndef INDIVIDUAL_H_
#define INDIVIDUAL_H_
#include"read_data.h"
struct Node;
struct Route{
	int cour;
	int nbClients;
	int whenLastModified;	// 这条路径最后一次被修改的时间
	int start;
	double dis;					// 路径上的总时间
};
struct Node{
	int cour; // 城市索引
	int position;
	int auxPos; // 这个变量用于在交叉操作符中分割巨型路径
	int whenLastTestedRI; // MOVES评估这个节点的时间
	Node *next;
	Node *pre;
	Route *route;
	double cumulatedDis;	// 在这条路径上到该客户的累积距离（包括其本身）
};

class Individual{
public:
	// 方法
	Individual();
	virtual ~Individual();
	void define(read_data *data);
	// 深度复制路径，重建 next/pre/route 指针
	void copyFrom(const Individual *other);
	void evaluationDis();
	void initilization();
	void updateRouteInfor(int &r);
	void outputSolution();
	void isRight();
	void isRightGTSP();  // GTSP解的验证
	void outputBestSolution();
	// 用于种群管理
	double brokenPairsDistance(Individual * indiv2);
	double averageBrokenPairsDistanceClosest(int nbClosest);
	void removeProximity(Individual * indiv);
	// 变量
	Node *client;
	int * start;
	Route * route;
	double dis;
	double biasedFit;
	bool isFeasible;
	std::multiset < std::pair < double, Individual* > > indivsPerProximity ;	// 种群中的其他个体，按近似度递增排序（set容器按照对的第一个值遵循自然排序）

private:
	read_data *data;
	int num_v;
	int num_p;
	int *usedTwoVerify;
};
#endif /* INDI_H_ */
