#include "read_data.h"
#include "Individual.h"
#include "initialsol.h"
#include "MyLS.h"
#include <iostream>
#include <string>
#include <ctime>
#include <chrono>

int main(int argc, char* argv[]) {
    std::cout << "========================================" << std::endl;
    std::cout << "  MyLS Test Program" << std::endl;
    std::cout << "========================================" << std::endl;
    std::cout << std::endl;
    
    // 解析命令行参数
    std::string instanceFile = "ESC07.pcgtsp";
    int seed = -1;  // -1 表示自动生成
    
    if (argc > 1) instanceFile = argv[1];
    if (argc > 2) seed = atoi(argv[2]);
    
    // 如果seed小于等于0，使用当前时间自动生成
    if (seed <= 0) {
        seed = static_cast<int>(time(NULL));
        std::cout << "Auto-generated seed: " << seed << std::endl; 
    }
    
    std::cout << "Instance: " << instanceFile << std::endl;
    std::cout << "Seed: " << seed << std::endl;
    std::cout << std::endl;
    
    // 初始化随机种子
    srand(seed);
    
    // 读取GTSP实例
    std::cout << "Reading GTSP instance file..." << std::endl;
    read_data* data = new read_data();
    std::string outputFile = "solution_test.txt";
    int p = 1;
    double knownBest = 100.0;
    int isOptimal = 0;
    int timeLimit = 3600;
    int iterLimit = 100000;
    
    data->read_gtsp(instanceFile, outputFile, p, knownBest, isOptimal, timeLimit, iterLimit, seed);
    
    std::cout << "Instance loaded: " << data->num_v << " nodes, " << data->num_groups << " groups" << std::endl;
    std::cout << std::endl;
    
    // 生成初始解
    std::cout << "========================================" << std::endl;
    std::cout << "  Generating Initial Solution" << std::endl;
    std::cout << "========================================" << std::endl;
    Individual* currentSol = new Individual();
    currentSol->define(data);
    
    initial_sol* initSol = new initial_sol(data);
    initSol->initial_solution(currentSol);

    double initialDistance = currentSol->dis;
    std::cout << "Initial solution distance: " << initialDistance << std::endl;
    std::cout << std::endl;
    
    // 验证初始解
    std::cout << "Validating initial solution:" << std::endl;
    currentSol->isRightGTSP();
    std::cout << std::endl;
    
    // 执行MyLS局部搜索
    std::cout << "========================================" << std::endl;
    std::cout << "  Running MyLS " << std::endl;
    std::cout << "========================================" << std::endl;
    
    // 开始计时
    auto startTime = std::chrono::high_resolution_clock::now();
    
    MyLS* myls = new MyLS(data);
    
    for (int run = 0; run < 100000; run++) {
        myls->local_search_run(currentSol);
        
        // 每1000次输出进度
        if ((run + 1) % 1000 == 0) {
            std::cout << "Progress: " << (run + 1) << "/10000 runs completed" << std::endl;
        }
    }
    
    // 结束计时
    auto endTime = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);
    double seconds = duration.count() / 1000.0;
    
    double finalDistance = currentSol->dis;
    std::cout << std::endl;
    
    // 验证最终解
    std::cout << "Validating final solution:" << std::endl;
    
    // 先输出路径
    std::cout << "Final path: ";
    Node* pathNode = &currentSol->client[currentSol->start[0]];
    bool isFirst = true;
    while (pathNode->cour != currentSol->start[0] || isFirst) {
        std::cout << pathNode->cour << " -> ";
        pathNode = pathNode->next;
        isFirst = false;
    }
    std::cout << currentSol->start[0] << std::endl;
    
    currentSol->isRightGTSP();
    std::cout << std::endl;
    
    // 输出结果
    std::cout << "========================================" << std::endl;
    std::cout << "  Final Results" << std::endl;
    std::cout << "========================================" << std::endl;
    std::cout << "Initial distance: " << initialDistance << std::endl;
    std::cout << "Final distance:   " << finalDistance << std::endl;
    std::cout << "Improvement:      " << (initialDistance - finalDistance) << std::endl;
    std::cout << "Improvement %:    " << ((initialDistance - finalDistance) / initialDistance * 100.0) << "%" << std::endl;
    std::cout << "Computation time: " << seconds << " seconds" << std::endl;
    std::cout << std::endl;
    
    // 输出最终路径
    std::cout << "Final tour (0-based indices):" << std::endl;
    currentSol->outputSolution();
    std::cout << std::endl;
    
    // 清理内存
    delete myls;
    delete initSol;
    delete currentSol;
    delete data;
    
    std::cout << "Test completed successfully!" << std::endl;
    
    return 0;
}
