#ifndef LS_GTSP_BASE_H_
#define LS_GTSP_BASE_H_

#include "Individual.h"

// 局部搜索基类接口
class LS_GTSP_Base {
public:
    virtual ~LS_GTSP_Base() {}
    
    // 纯虚函数，子类必须实现
    virtual void local_search_run(Individual *s) = 0;
};

#endif /* LS_GTSP_BASE_H_ */
