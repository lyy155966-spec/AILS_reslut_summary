#include "Individual.h"
#include <vector>

Individual::Individual() {

}
Individual::~Individual() {
	delete [] client;
	delete [] route;
	delete [] usedTwoVerify;
	delete [] start;
}
void Individual::define(read_data *data){
	this->data=data;
	this->num_v=data->num_v;
	this->num_p=data->num_p;
	this->num_v=data->num_v;
	client=new Node [num_v];
	for (int i=0;i<num_v;i++){
		client[i].cour=i;
		client[i].pre=NULL;
		client[i].next=NULL;
		client[i].route=NULL;
	}
	start=new int [num_p];
	route=new Route [num_p];
	for (int i=0;i<num_p;i++)
		route[i].cour=i;
	//
	usedTwoVerify=new int [num_v];
}

// Deep-copy the tour structure from another Individual
void Individual::copyFrom(const Individual *other){
    // Copy meta
    this->data = other->data;
    this->num_v = other->num_v;
    this->num_p = other->num_p;

    // Copy start (assume single route p=1 for GTSP)
    this->start[0] = other->start[0];

    // Extract source tour order
    std::vector<int> tour;
    Node *cur = &other->client[other->start[0]];
    bool isFirst = true;
    while (cur->cour != other->start[0] || isFirst){
        tour.push_back(cur->cour);
        cur = cur->next;
        isFirst = false;
    }

    // Rebuild pointers in this individual according to tour
    for (size_t i = 0; i < tour.size(); i++){
        int c = tour[i];
        int n = tour[(i + 1) % tour.size()];
        client[c].cour = c;
        client[c].next = &client[n];
        client[n].pre = &client[c];
        client[c].route = &route[0];
    }

    // Set route start
    route[0].start = this->start[0];

    // Update route info and total distance
    int r = 0;
    this->updateRouteInfor(r);
    this->evaluationDis();
}
//计算距离
void Individual::evaluationDis(){
	dis=0;
	Node *p;bool isFirst;
	for (int i=0;i<num_p;i++){
		p=&client[start[i]];
		isFirst=true;
		while(p->cour != start[i] || isFirst){
			dis += data->D[p->cour][p->next->cour];
			p=p->next;
			isFirst=false;
		}
	}
}

//更新路径信息
void Individual::updateRouteInfor(int &r){
	Node *p=&client[start[r]];
	p->position=0;
	p->cumulatedDis = 0;
	bool isFirst=true;
	
	while(p->cour != start[r] || isFirst){
		p=p->next;
		p->position=p->pre->position+1;
		p->cumulatedDis=data->D[p->cour][p->pre->cour]+p->pre->cumulatedDis;
		isFirst = false;
	}
	
	route[r].dis =p->pre->cumulatedDis + data->D[p->pre->cour][p->cour];
	route[r].nbClients=p->pre->position+1;
}

void Individual::outputSolution(){
	std::cout<<"The solution display is as follows"<<std::endl;
	bool isFirst;Node *p;
	for (int i=0;i<num_p;i++){
		p=&client[start[i]];
		isFirst = true;
		std::cout<<i<<" tour & depot is "<<p->cour<<" :: ";
		while(p->cour != start[i] || isFirst){
			std::cout<<p->cour<<" ";
			p=p->next;
			isFirst = false;
		}
		std::cout<<start[i]<<std::endl;
	}
}

void Individual::isRight(){
	double real_dis=0;
	for (int i=0;i<num_v;i++)usedTwoVerify[i]=0;
	Node *p;bool isFirst;
	int nbRoute[num_p];
	for (int i=0;i<num_p;i++){
		nbRoute[i]=0;
		p=&client[start[i]];
		isFirst=true;
		while(p->cour != start[i] || isFirst){
			usedTwoVerify[p->cour]++;
			nbRoute[i]++;
			real_dis += data->D[p->cour][p->next->cour];
			p=p->next;
			isFirst = false;
		}
	}
	if (!((real_dis + Min) > dis && (real_dis - Min) <dis))
		std::cout<<"The total distance is wrong"<<std::endl;
	for (int i=0;i<num_v;i++)
		if (usedTwoVerify[i] != 1)
			std::cout<<"The "<<i<<"th"<<"vertex is wrong"<<std::endl;
	real_dis=0;
	for (int i=0;i<num_p;i++){
		if (nbRoute[i] != route[i].nbClients || nbRoute[i] < 3){
			std::cout<<"The "<<i<<" tour is wrong"<<std::endl;
			exit(0);
		}
		real_dis += route[i].dis;
	}
	if (!((real_dis + Min) > dis && (real_dis - Min) <dis))
		std::cout<<"The update Route Infor is wrong"<<std::endl;
}

void Individual::isRightGTSP(){
	// check if solution satisfies all constraints
	
	//验证起始点是否为节点0
	if (start[0] != 0) {
		std::cout << "Error: Start node is " << start[0] << ", expected 0" << std::endl;
	}
	
	double real_dis=0;
	for (int i=0;i<num_v;i++)usedTwoVerify[i]=0;
	Node *p;bool isFirst;
	int nbRoute[num_p];
	
	// Collect visited nodes and calculate distance
	for (int i=0;i<num_p;i++){
		nbRoute[i]=0;
		p=&client[start[i]];
		isFirst=true;
		while(p->cour != start[i] || isFirst){
			usedTwoVerify[p->cour]++;
			nbRoute[i]++;
			real_dis += data->D[p->cour][p->next->cour];
			p=p->next;
			isFirst = false;
		}
	}
	
	// Check distance calculation
	if (!((real_dis + Min) > dis && (real_dis - Min) <dis))
		std::cout<<"The total distance is wrong"<<std::endl;
	
	// Check each cluster has exactly one node selected
	std::vector<int> clusterCount(data->num_groups + 1, 0);
	for (int i=0; i<num_v; i++){
		if (usedTwoVerify[i] == 1){
			int cluster = data->nodeGroup[i];
			clusterCount[cluster]++;
		}
	}
	
	bool clusterConstraintOK = true;
	for (int g=1; g<=data->num_groups; g++){
		if (clusterCount[g] != 1){
			std::cout<<"Error: Cluster "<<g<<" has "<<clusterCount[g]<<" nodes (should be 1)"<<std::endl;
			clusterConstraintOK = false;
		}
	}
	
	if (clusterConstraintOK){
		std::cout<<"OK: Each cluster has exactly one node selected"<<std::endl;
	}
	
	// Check precedence constraints
	std::vector<int> visitedNodes;
	std::vector<int> nodePosition(num_v, -1);
	
	for (int i=0; i<num_p; i++){
		p=&client[start[i]];
		isFirst=true;
		int pos = 0;
		while(p->cour != start[i] || isFirst){
			visitedNodes.push_back(p->cour);
			nodePosition[p->cour] = pos++;
			p=p->next;
			isFirst = false;
		}
	}
	
	bool precedenceOK = true;
	int violationCount = 0;
	for (int i : visitedNodes){
		for (int j : visitedNodes){
			if (data->precedenceConstraints[i][j] == -1){
				// i must come after j
				if (nodePosition[i] < nodePosition[j]){
					std::cout<<"Error: Node "<<(i+1)<<" should come after Node "<<(j+1)<<std::endl;
					precedenceOK = false;
					violationCount++;
				}
			}
		}
	}
	
	if (precedenceOK){
		std::cout<<"OK: All precedence constraints satisfied"<<std::endl;
	} else {
		std::cout<<"Total precedence violations: "<<violationCount<<std::endl;
	}

	std::cout<<"-----------------------------------------------"<<std::endl;
	std::cout<<"Solution validation complete."<<std::endl;
}

/**************************************************************** */
//未被调用

//输出解（未被调用）
void Individual::outputBestSolution(){
	std::cout<<"----------Write Solution With Value  "<<dis<<" In: "<<data->pathSolution<<std::endl;
	std::ofstream myfile(data->pathSolution);
	double real_dis=0;
	Node *p;bool isFirst;
	for (int i=0;i<num_v;i++)usedTwoVerify[i]=0;
	for (int i=0;i<num_p;i++){
		p=&client[start[i]];
		usedTwoVerify[p->cour]++;
		isFirst=true;
		while(p->cour != start[i] || isFirst){
			p=p->next;
			usedTwoVerify[p->cour]++;
			real_dis += data->D[p->cour][p->pre->cour];
			isFirst = false;
		}
	}
	if (myfile.is_open()){
		myfile<<"The instance is "<<data->pathInstance<<std::endl;
		myfile<<"The number of p is "<<data->num_p<<std::endl;
		if (std::abs(data->bestDis - dis) < 0.01 && data->isOptimal)
			myfile<<"The output solution is optimal "<<std::endl;
		else
			myfile<<"The output solution is non-optimal "<<std::endl;
		myfile<<"The real Distance is: "<<std::endl<<std::fixed<<std::setprecision(2)<<real_dis<<std::endl;
		myfile<<"The time which meets the best is: "<<std::endl<<data->meetBestTime<<std::endl;
		myfile << "The time consuming is  " <<std::endl<< (double)clock()/(double)CLOCKS_PER_SEC << std::endl;
		myfile<<"The time to meet the Best solution is "<<std::endl<< data->timeToTarget<<std::endl;
		for (int i=0;i<num_p;i++){
			p=&client[start[i]];
			isFirst=true;
			myfile<<i<<" tour starts "<<p->cour<<": ";
			while (p->cour != start[i] || isFirst){
				myfile<<p->cour<<" ";
				p=p->next;
				isFirst = false;
			}
			myfile<<start[i]<<std::endl;
		}
	}
	else std::cout << "----- IMPOSSIBLE TO OPEN: " << data->pathSolution << std::endl;
}
void Individual::removeProximity(Individual * indiv){
	auto it = indivsPerProximity.begin();
	while (it->second != indiv) ++it;
	indivsPerProximity.erase(it);
}
double Individual::averageBrokenPairsDistanceClosest(int nbClosest){
	double result = 0 ;
	int maxSize = std::min<int>(nbClosest, indivsPerProximity.size());
	auto it = indivsPerProximity.begin();
	for (int i=0 ; i < maxSize; i++){
		result += it->first ;
		++it ;
	}
	return result/(double)maxSize ;
}

double Individual::brokenPairsDistance(Individual * indiv){
	int nbOverlap=0;
	Node *nodeU, *nodeV;
	bool isFirst;
	for (int i=0;i<num_p;i++){
		nodeU=&client[start[i]];
		nodeV=nodeU->next;
		isFirst=true;
		while(nodeU->cour != start[i] || isFirst){
			if (indiv->client[nodeU->cour].pre->cour == nodeV->cour || indiv->client[nodeU->cour].next->cour == nodeV->cour)
				nbOverlap++;
			nodeU=nodeU->next;
			nodeV=&indiv->client[nodeU->cour];
			isFirst=false;
		}
	}
	return ((double)(num_v - nbOverlap));
}
