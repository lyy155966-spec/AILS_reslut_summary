#include "read_data.h"
#include "Individual.h"
#include "initialsol.h"
#include "MyLS.h"
#include "SA_Enhanced.h"
#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <chrono>

int main(int argc, char* argv[]) {
    std::cout << "GTSP" << std::endl;
    // 解析命令行参数
    std::string instanceFile = "ESC07.pcgtsp";
    int seed = -1;  // -1 表示自动生成
    int maxIterations = 1000;
    //参数解析
    if (argc > 1) instanceFile = argv[1];
    if (argc > 2) seed = atoi(argv[2]);
    if (argc > 3) maxIterations = atoi(argv[3]);
    
    // 如果seed小于等于0，使用当前时间自动生成
    if (seed <= 0) {
        seed = static_cast<int>(time(NULL));
        std::cout << "Auto-generated seed: " << seed << std::endl; 
    }
    
    std::cout << "Instance: " << instanceFile << std::endl;
    std::cout << "Seed: " << seed << std::endl;
    std::cout << "Max Iterations: " << maxIterations << std::endl;
    std::cout << std::endl;
    
    // Initialize random seed
    srand(seed);
    
    // Read GTSP instance
    std::cout << "Reading GTSP instance file..." << std::endl;
    read_data* data = new read_data();
    std::string outputFile = "solution_ils.txt"; // 输出文件
    int p = 1;
    double knownBest = 100.0;//用于判断是否达到最优解（当前未使用）
    int isOptimal = 0;//是否最优
    int timeLimit = 3600;//时间限制（现在是没使用的）
    int iterLimit = 100000;//迭代次数限制（现在是没使用的）
    
    data->read_gtsp(instanceFile, outputFile, p, knownBest, isOptimal, timeLimit, iterLimit, seed);//读取GTSP实例
    
    std::cout << "Instance loaded: " << data->num_v << " nodes, " << data->num_groups << " groups" << std::endl;
    
    // Generate initial solution
    std::cout << "Initial Solution" << std::endl;
    Individual* currentSol = new Individual();
    currentSol->define(data);
    
    initial_sol* initSol = new initial_sol(data);
    initSol->initial_solution(currentSol);

    std::cout << "Initial solution distance: " << currentSol->dis << std::endl;
    std::cout << std::endl;
    
    // 初始局部搜索
    std::cout << "Initial Local Search " << std::endl;

    // 使用 MyLS 进行局部搜索
    MyLS* ls = new MyLS(data);
    ls->local_search_run(currentSol); 
    
    double initialDistance = currentSol->dis;  // 保存初始解的距离
    double bestDistance = currentSol->dis;
    std::cout << "After initial LS: " << bestDistance << std::endl;
    std::cout << std::endl;
    
    // 三解管理系统
    Individual* globalBest = new Individual();  // 全局最优解
    Individual* localBest = new Individual();   // 局部最优解
    globalBest->define(data);
    localBest->define(data);
    
    globalBest->copyFrom(currentSol);
    localBest->copyFrom(currentSol);
    
    // 迭代局部搜索
    std::cout << "Iterated Local Search" << std::endl;
    
    // 开始计时
    auto startTime = std::chrono::high_resolution_clock::now();
    
    // 创建SA_Enhanced扰动器
    SA_Enhanced* saEnhanced = new SA_Enhanced(data);
    
    // 设置三解管理
    saEnhanced->setGlobalBest(globalBest);
    saEnhanced->setLocalBest(localBest);
    
    // 基于初始解设置温度（自动计算冷却率以达到约6000次迭代）
    saEnhanced->initializeTemperature(currentSol);
    
    // 原始Perturbation
    // Perturbation* perturb = new Perturbation(data);
    
    // SA.cpp的segment机制
    int restartInterval = 100000000;           // 每20个segment完全重启（1000次迭代）此时设置的非常大，实际没有用
    int episodeLength = 50;             // 每50次迭代为一个episode
    
    int bestFoundAtIteration = 0;       // 记录最优解是在第几次迭代找到的
    int finalIteration = 0;             // 最终迭代次数

    saEnhanced->run(currentSol,
                    ls,
                    bestDistance,
                    bestFoundAtIteration,
                    finalIteration,
                    0.000005,
                    episodeLength,
                    restartInterval);//参数调节
    
    // 结束时间计时
    auto endTime = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);
    double seconds = duration.count() / 1000.0;
    
    std::cout << std::endl;
    std::cout << "========================================" << std::endl;
    std::cout << "  Final Results" << std::endl;
    std::cout << "========================================" << std::endl;
    std::cout << "Initial solution distance: " << initialDistance << std::endl;
    std::cout << "Best distance found: " << bestDistance << std::endl;
    std::cout << "Improvement: " << (initialDistance - bestDistance) << " (" << ((initialDistance - bestDistance) / initialDistance * 100.0) << "%)" << std::endl;
    std::cout << "Best solution found at iteration: " << bestFoundAtIteration << std::endl;
    std::cout << "Total iterations: " << finalIteration << std::endl;
    std::cout << "Termination reason: Temperature too low" << std::endl;
    std::cout << "Total computation time: " << seconds << " seconds" << std::endl;
    std::cout << std::endl;
    
    std::cout << "Best tour:" << std::endl;
    globalBest->outputSolution();
    std::cout << std::endl;
    
    // 输出路径信息
    std::cout << "Best path (0-based node indices):" << std::endl;//以索引开始的
    std::cout << "  ";
    Node* current = &globalBest->client[globalBest->start[0]];
    Node* first = current;
    bool isFirst = true;
    std::vector<int> path;
    while (current->cour != globalBest->start[0] || isFirst) {
        path.push_back(current->cour);
        std::cout << current->cour;
        current = current->next;
        if (current->cour != globalBest->start[0] || !isFirst) {
            std::cout << " -> ";
        }
        isFirst = false;
    }
    std::cout << current->cour << std::endl;  // 回到起点

    std::cout << "\nBest path (1-based node indices, as in input file):" << std::endl;//以文件中格式开始的
    std::cout << "  ";
    for (size_t i = 0; i < path.size(); i++) {
        std::cout << (path[i] + 1);
        if (i < path.size() - 1) std::cout << " -> ";
    }
    std::cout << " -> " << (globalBest->start[0] + 1) << std::endl;
    
    // 输出路径长度信息
    std::cout << "\nPath details:" << std::endl;
    std::cout << "  Number of clusters visited: " << path.size() << std::endl;
    std::cout << "  Starting and ending node: " << globalBest->start[0] << " (1-based: " << (globalBest->start[0] + 1) << ")" << std::endl;
    std::cout << "  Total distance: " << bestDistance << std::endl;
    std::cout << std::endl;
    
    // isright
    std::cout << "Validating best solution:" << std::endl;
    globalBest->isRightGTSP();
    
    // clear
    delete saEnhanced;
    delete ls;
    delete initSol;
    delete globalBest;
    delete localBest;
    delete currentSol;
    delete data;
    
    return 0;
}
