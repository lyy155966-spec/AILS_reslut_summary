/*
 * basic.h
 *
 *  Created on: 18 Apr 2020
 *      Author: Peng
 */

#ifndef BASIC_H_
#define BASIC_H_
#include<algorithm>
#include <vector>
#include <set>
#include <unordered_set>
#include <list>
#include<math.h>
#include <iostream>
#include <time.h>
#include <string>
#include <fstream>
#include <iomanip>
///////////////////////////////////////////////////////////////////////////////
#define PI 3.141592
#define Max 100000000
#define Min 0.01

#endif /* BASIC_H_ */
